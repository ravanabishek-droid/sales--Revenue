/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Enable JSON parser for POST request payloads
app.use(express.json());

// Lazy-loaded or safely-retrieved Google GenAI Client
let aiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    throw new Error("GEMINI_API_KEY environment variable is not configured or remains default.");
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// 1. Health check routing
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

// 2. AI Sales & Revenue Insights generator
app.post("/api/insights", async (req, res) => {
  try {
    const { kpi, categoryData, regionalData, leaderboard, hasFilter } = req.body;

    if (!kpi) {
      res.status(400).json({ error: "Missing KPI stats context." });
      return;
    }

    // Attempt to initialize GenAI safely
    let ai;
    try {
      ai = getAiClient();
    } catch (keyError: any) {
      // Return beautiful default insight report if key is unconfigured
      // to keep usability high even in empty environments
      res.json({
        insights: `### 📊 Real-Time Business Analysis

*Note: Live AI insights will activate once your **GEMINI_API_KEY** is configured in the Secrets pane.*

#### 🔑 Key KPI Performance
- **Revenue Strength**: Total sales evaluated at **$${(kpi.totalRevenue || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}**.
- **Margin Profile**: Overall gross profit margin stands at **${(kpi.avgMargin || 0).toFixed(1)}%**, showing a sound pricing framework.
- **Average Ticket**: The Average Order Value (AOV) is **$${(kpi.avgOrderValue || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}** based on **${kpi.totalOrders || 0}** transactions.

#### 📈 Strategic Strategy Targets
1. **Optimize High-Volume Products**: Focus on driving top items (like those in ${categoryData && categoryData[0] ? categoryData[0].category : 'Electronics'}) where demand is concentrated.
2. **Support Higher Margins**: Evaluate lower margin items to boost cost efficiencies and drive overall profitability up toward ${((kpi.avgMargin || 0) + 5).toFixed(0)}%.
3. **Region Focus**: Focus sales efforts on your leading markets, while piloting target campaigns in lower-performing channels.`,
        isDemo: true,
        message: "Demo insights returned. Configure GEMINI_API_KEY in Settings to enable real-time dynamic analysis."
      });
      return;
    }

    // Format metrics into a highly analytical prompt for our expert retail consultant model
    const promptText = `
Analyze the following sales and revenue metrics from our retail/e-commerce operations and generate a highly detailed, professional, executive business report.

--- EXECUTIVE SUMMARY & METRICS ---
${hasFilter ? '[NOTE: These metrics are filtered based on the user\'s active dashboard drill-down]' : '[NOTE: These metrics are overall business metrics]'}
- Total Revenue Generated: $${kpi.totalRevenue?.toLocaleString()}
- Total Profit Captured: $${kpi.totalProfit?.toLocaleString()}
- Average Gross Profit Margin: ${kpi.avgMargin?.toFixed(1)}%
- Total Orders Placed: ${kpi.totalOrders}
- Average Order Value (AOV): $${kpi.avgOrderValue?.toFixed(2)}
- Total Units Handled/Sold: ${kpi.totalQuantity}

--- CATEGORY SEGMENT PERFORMANCE ---
${(categoryData || []).map((c: any) => `- ${c.category}: Revenue = $${c.revenue?.toLocaleString()}, Profit = $${c.profit?.toLocaleString()}, Units = ${c.units} (Margin = ${((c.profit / (c.revenue || 1)) * 100).toFixed(1)}%)`).join('\n')}

--- REGIONAL DRILLDOWN ---
${(regionalData || []).map((r: any) => `- ${r.region}: Revenue = $${r.revenue?.toLocaleString()}, Units = ${r.units}`).join('\n')}

--- TOP PERFORMING PRODUCTS (LEADERBOARD) ---
${(leaderboard || []).slice(0, 5).map((p: any, idx: number) => `${idx + 1}. ${p.product} (Category: ${p.category}): Revenue = $${p.revenue?.toLocaleString()}, Units = ${p.units}, Margin = ${p.margin?.toFixed(1)}%`).join('\n')}

--- REPORT REQUIREMENTS ---
Please deliver a highly professional report styled in valid Markdown. Provide:
1. **Executive Assessment (KPI Evaluation)**: Detail what these numbers reveal about the business physical status, pricing efficiency, and overall cash generation.
2. **Product Segment Observations**: Highlight the standout categories and top-performing products. Identify which units are cash-cows versus value drains.
3. **Regional Insights & Slicers Analysis**: Touch upon which geographical markets or sales modes are driving the scale.
4. **Concrete Actionable Recommendations**: Give 3-4 specific tactical and strategic directives (like inventory restocks, price changes, or targeting tweaks) that would immediately boost top-line revenue or bottom-line margin. Use bold accents, scannable elements, and clear, structured paragraphs. Ensure it reads like a premium McKinsey or Gartner corporate advisory.
`;

    // Retrieve dynamically from Gemini 3.5 Flash server-side
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: promptText,
      config: {
        systemInstruction: "You are an elite, highly logical senior retail consultant and business developer. Speak with direct numerical confidence; use markdown structure cleanly; do not praise yourself or write fluff."
      }
    });

    res.json({
      insights: response.text,
      isDemo: false
    });

  } catch (error: any) {
    console.error("Gemini Insight Endpoint Error:", error);
    res.status(500).json({
      error: "Error processing business insights.",
      details: error.message || error
    });
  }
});

// Vite Middleware & production static distribution routing
async function configureViteAndStatic() {
  if (process.env.NODE_ENV !== "production") {
    // Development mode with real-time Vite pipeline
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production delivery of compiled static frontend
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Graceful port binding with dynamic port fallback & retries
  const maxPortAttempts = 10;
  const maxRetrySamePort = 5;
  const retryDelayMs = 1500;

  function startServer(port: number, attempt: number, samePortRetryCount = 0) {
    const server = app.listen(port, "0.0.0.0", () => {
      console.log(`[Fullstack Server] Ready! Access your app at: http://localhost:${port}`);
    });

    server.on("error", (error: any) => {
      if (error.code === "EADDRINUSE") {
        console.warn(`[Fullstack Server] Port ${port} is already in use.`);
        
        // DISABLE_HMR is set to "true" in AI Studio, indicating sandboxed context
        const isAiStudio = process.env.DISABLE_HMR === "true" || !!process.env.AISTUDIO_BUILD;

        if (isAiStudio) {
          if (samePortRetryCount < maxRetrySamePort) {
            const nextRetry = samePortRetryCount + 1;
            console.log(`[Fullstack Server] AI Studio sandbox detected. Port ${port} is occupied. Retrying same port in ${retryDelayMs}ms... (Attempt ${nextRetry}/${maxRetrySamePort})`);
            setTimeout(() => {
              startServer(port, attempt, nextRetry);
            }, retryDelayMs);
          } else {
            console.error(`[Fullstack Server] Critical Error: Port ${port} is occupied inside the AI Studio sandbox after ${maxRetrySamePort} retries. Exiting system process.`);
            process.exit(1);
          }
        } else {
          if (attempt < maxPortAttempts) {
            const nextPort = port + 1;
            console.log(`[Fullstack Server] Local dev space detected. Automatically trying next available port ${nextPort}... (Attempt ${attempt}/${maxPortAttempts})`);
            startServer(nextPort, attempt + 1);
          } else {
            console.error(`[Fullstack Server] Failed to bind to any port after ${maxPortAttempts} attempts. Exiting.`);
            process.exit(1);
          }
        }
      } else {
        console.error(`[Fullstack Server] Server setup error occurred:`, error);
        process.exit(1);
      }
    });
  }

  startServer(PORT, 1);
}

configureViteAndStatic();
