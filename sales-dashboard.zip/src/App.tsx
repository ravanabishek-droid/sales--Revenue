/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from "react";
import { 
  TrendingUp, 
  DollarSign, 
  Percent, 
  ShoppingBag, 
  Layers, 
  FileCheck2, 
  Info,
  ExternalLink 
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

import { Transaction, DashboardFilters, KpiSummary, CategoryBreakdown, RegionalBreakdown, ProductLeaderboard, MonthlyTrend } from "./types";
import { DEFAULT_TRANSACTIONS } from "./data";

import KpiCard from "./components/KpiCard";
import ExecutiveSlideshow from "./components/ExecutiveSlideshow";
import FiltersBar from "./components/FiltersBar";
import InteractiveCharts from "./components/InteractiveCharts";
import AiAdvisor from "./components/AiAdvisor";
import TransactionsTable from "./components/TransactionsTable";
import PowerBiSqlWorkspace from "./components/PowerBiSqlWorkspace";

export default function App() {
  // Toggle between Executive Dashboard and Power BI Live SQL Modes
  const [viewMode, setViewMode] = useState<"dashboard" | "powerbi">("dashboard");

  // Initialize Transaction ledger from localStorage with our pre-populated dataset fallback
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem("sales_revenue_transactions");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Failed to parse saved transactions, loading defaults...", e);
      }
    }
    return DEFAULT_TRANSACTIONS;
  });

  // Save changes automatically
  useEffect(() => {
    localStorage.setItem("sales_revenue_transactions", JSON.stringify(transactions));
  }, [transactions]);

  // Initial Filter Defaults
  const [filters, setFilters] = useState<DashboardFilters>({
    startDate: "",
    endDate: "",
    category: "All",
    region: "All",
    channel: "All",
    paymentMethod: "All",
    searchQuery: ""
  });

  // 1. Dynamic filtering logic
  const filteredTransactions = useMemo(() => {
    return transactions.filter((t) => {
      // Date bounds check
      if (filters.startDate && t.date < filters.startDate) return false;
      if (filters.endDate && t.date > filters.endDate) return false;

      // Category match
      if (filters.category !== "All" && t.category !== filters.category) return false;

      // Region match
      if (filters.region !== "All" && t.region !== filters.region) return false;

      // Sales Channel match
      if (filters.channel !== "All" && t.channel !== filters.channel) return false;

      // Payment Method match
      if (filters.paymentMethod !== "All" && t.paymentMethod !== filters.paymentMethod) return false;

      // Search Query
      if (filters.searchQuery.trim()) {
        const query = filters.searchQuery.toLowerCase();
        const matchesProduct = t.product.toLowerCase().includes(query);
        const matchesInvoice = t.id.toLowerCase().includes(query);
        const matchesCategory = t.category.toLowerCase().includes(query);
        if (!matchesProduct && !matchesInvoice && !matchesCategory) return false;
      }

      return true;
    });
  }, [transactions, filters]);

  // Determine if active filters are being applied (useful context flag for the AI advisor)
  const isFiltered = useMemo(() => {
    return (
      filters.startDate !== "" ||
      filters.endDate !== "" ||
      filters.category !== "All" ||
      filters.region !== "All" ||
      filters.channel !== "All" ||
      filters.paymentMethod !== "All" ||
      filters.searchQuery !== ""
    );
  }, [filters]);

  // 2. Calculations of KPI summarized metrics over the filtered dataset
  const kpiStats = useMemo<KpiSummary>(() => {
    const totalRevenue = filteredTransactions.reduce((acc, curr) => acc + curr.revenue, 0);
    const totalProfit = filteredTransactions.reduce((acc, curr) => acc + curr.profit, 0);
    const totalOrders = filteredTransactions.length;
    const totalQuantity = filteredTransactions.reduce((acc, curr) => acc + curr.quantity, 0);
    
    const avgMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;
    const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

    return {
      totalRevenue: parseFloat(totalRevenue.toFixed(2)),
      totalProfit: parseFloat(totalProfit.toFixed(2)),
      avgMargin: parseFloat(avgMargin.toFixed(1)),
      totalOrders,
      avgOrderValue: parseFloat(avgOrderValue.toFixed(2)),
      totalQuantity
    };
  }, [filteredTransactions]);

  // 3. Segmented Summaries: Category Breakdown
  const categoryBreakdown = useMemo<CategoryBreakdown[]>(() => {
    const countsMap: { [key: string]: { rev: number; prof: number; units: number } } = {};

    filteredTransactions.forEach((t) => {
      if (!countsMap[t.category]) {
        countsMap[t.category] = { rev: 0, prof: 0, units: 0 };
      }
      countsMap[t.category].rev += t.revenue;
      countsMap[t.category].prof += t.profit;
      countsMap[t.category].units += t.quantity;
    });

    return Object.keys(countsMap).map((cat) => ({
      category: cat,
      revenue: parseFloat(countsMap[cat].rev.toFixed(2)),
      profit: parseFloat(countsMap[cat].prof.toFixed(2)),
      units: countsMap[cat].units
    })).sort((a, b) => b.revenue - a.revenue);
  }, [filteredTransactions]);

  // 4. Segmented Summaries: Regional Breakdown
  const regionalBreakdown = useMemo<RegionalBreakdown[]>(() => {
    const countsMap: { [key: string]: { rev: number; units: number; prof: number } } = {};

    filteredTransactions.forEach((t) => {
      if (!countsMap[t.region]) {
        countsMap[t.region] = { rev: 0, units: 0, prof: 0 };
      }
      countsMap[t.region].rev += t.revenue;
      countsMap[t.region].units += t.quantity;
      countsMap[t.region].prof += t.profit;
    });

    return Object.keys(countsMap).map((reg) => ({
      region: reg,
      revenue: parseFloat(countsMap[reg].rev.toFixed(2)),
      units: countsMap[reg].units,
      profit: parseFloat(countsMap[reg].prof.toFixed(2))
    })).sort((a, b) => b.revenue - a.revenue);
  }, [filteredTransactions]);

  // 5. Leaderboard: Product performance rankings
  const productLeaderboard = useMemo<ProductLeaderboard[]>(() => {
    const prodMap: { 
      [key: string]: { cat: string; rev: number; units: number; prof: number } 
    } = {};

    filteredTransactions.forEach((t) => {
      if (!prodMap[t.product]) {
        prodMap[t.product] = { cat: t.category, rev: 0, units: 0, prof: 0 };
      }
      prodMap[t.product].rev += t.revenue;
      prodMap[t.product].units += t.quantity;
      prodMap[t.product].prof += t.profit;
    });

    return Object.keys(prodMap).map((prod) => {
      const p = prodMap[prod];
      const margin = p.rev > 0 ? (p.prof / p.rev) * 100 : 0;
      return {
        product: prod,
        category: p.cat,
        revenue: parseFloat(p.rev.toFixed(2)),
        units: p.units,
        profit: parseFloat(p.prof.toFixed(2)),
        margin: parseFloat(margin.toFixed(1))
      };
    }).sort((a, b) => b.revenue - a.revenue);
  }, [filteredTransactions]);

  // 6. Monthly chronological trends mapping (Sorted chronologically from oldest to newest)
  const monthlyTrends = useMemo<MonthlyTrend[]>(() => {
    const monthMap: { [key: string]: { rev: number; prof: number; units: number } } = {};

    filteredTransactions.forEach((t) => {
      const monthStr = t.date.slice(0, 7); // "YYYY-MM"
      if (!monthMap[monthStr]) {
        monthMap[monthStr] = { rev: 0, prof: 0, units: 0 };
      }
      monthMap[monthStr].rev += t.revenue;
      monthMap[monthStr].prof += t.profit;
      monthMap[monthStr].units += t.quantity;
    });

    return Object.keys(monthMap)
      .sort((a, b) => a.localeCompare(b))
      .map((m) => ({
        month: m,
        revenue: parseFloat(monthMap[m].rev.toFixed(2)),
        profit: parseFloat(monthMap[m].prof.toFixed(2)),
        units: monthMap[m].units
      }));
  }, [filteredTransactions]);

  // Filter setters
  const updateFilters = (updated: Partial<DashboardFilters>) => {
    setFilters((prev) => ({ ...prev, ...updated }));
  };

  const handleResetFilters = () => {
    setFilters({
      startDate: "",
      endDate: "",
      category: "All",
      region: "All",
      channel: "All",
      paymentMethod: "All",
      searchQuery: ""
    });
  };

  // Ledger state mutations
  const handleAddTransaction = (newT: Transaction) => {
    setTransactions((prev) => [newT, ...prev]);
  };

  const handleAddMultipleTransactions = (arr: Transaction[]) => {
    setTransactions((prev) => [...arr, ...prev]);
  };

  const handleDeleteTransaction = (id: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  const handleClearAll = () => {
    if (window.confirm("Are you sure you want to completely clear the sales register? This will purge all records.")) {
      setTransactions([]);
    }
  };

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleGlobalShortcuts = (e: KeyboardEvent) => {
      // Ignore shortcuts if user is typing in forms
      const target = e.target as HTMLElement;
      if (
        target.tagName === "INPUT" ||
        target.tagName === "SELECT" ||
        target.tagName === "TEXTAREA" ||
        target.isContentEditable
      ) {
        return;
      }

      // Alt+R: Reset Filters
      if (e.altKey && e.key.toLowerCase() === "r") {
        e.preventDefault();
        handleResetFilters();
      }

      // Alt+N: Toggle Add Sales Form
      if (e.altKey && e.key.toLowerCase() === "n") {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent("toggle-add-sale-form"));
      }
    };

    window.addEventListener("keydown", handleGlobalShortcuts);
    return () => {
      window.removeEventListener("keydown", handleGlobalShortcuts);
    };
  }, []);

  return (
    <div className="min-h-screen bg-[#050505] text-[#bbb] flex flex-col font-sans select-none antialiased">
      {/* 🌟 Professional Top Navigation Rail Bar */}
      <header className="bg-[#0c0c0c] border-b border-[#1a1a1a] py-4 px-6 md:px-12 flex flex-col sm:flex-row sm:items-center justify-between gap-4 sticky top-0 z-40 print:hidden">
        <div className="flex items-center gap-3">
          <div className="bg-[#c5a059] rounded-lg p-2 text-black">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-serif italic text-white tracking-tight">
                Executive Revenue Control Desk
              </h1>
              <span className="text-[10px] bg-[#c5a05911] text-[#c5a059] font-serif italic px-2 py-0.5 rounded border border-[#c5a05922]">
                Quantum Suite
              </span>
            </div>
            <p className="text-xs text-[#555] mt-0.5">
              Interactive sales analytics modeling, CSV import matrices, & AI core advisory forecasts.
            </p>
          </div>
        </div>

        {/* Interactive Workspace view selectors */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 text-xs font-mono">
          <div className="flex rounded-lg bg-[#111] p-1 border border-[#1e1e1e]">
            <button
              onClick={() => setViewMode("dashboard")}
              className={`px-3 py-1.5 rounded text-xs transition-all cursor-pointer ${
                viewMode === "dashboard"
                  ? "bg-[#c5a059] text-black font-semibold shadow-md"
                  : "text-[#888] hover:text-white"
              }`}
            >
              Dashboard View
            </button>
            <button
              onClick={() => setViewMode("powerbi")}
              className={`px-3 py-1.5 rounded text-xs transition-all cursor-pointer ${
                viewMode === "powerbi"
                  ? "bg-[#c5a059] text-black font-semibold shadow-md"
                  : "text-[#888] hover:text-white"
              }`}
            >
              Power BI Live SQL
            </button>
          </div>
          <span className="text-[#c5a059] font-serif italic text-xs hidden lg:inline">Active Sovereign Session</span>
        </div>
      </header>

      {/* 🚀 Main Central Deck Frame */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-8 flex flex-col gap-8">
        
        {/* 🖨️ Physical Print-Only Executive Header with Filter Slicers Metadata */}
        <div className="hidden print:block text-black border-b-4 border-black pb-4 mb-4">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-2xl font-serif font-bold tracking-tight text-black">
                Executive Revenue Control Desk
              </h1>
              <span className="text-[10px] uppercase tracking-widest text-[#555] font-mono font-bold block mt-1">
                Quantum Analytics Model Report Platform
              </span>
            </div>
            <div className="text-right text-xs font-mono text-stone-600">
              <div>REPORT GENERATED: {new Date().toLocaleDateString(undefined, { dateStyle: 'long' })}</div>
              <div>SESSION STATS: Verified Client Sandbox Registry</div>
            </div>
          </div>
          
          <div className="bg-stone-50 border border-stone-200 rounded-lg p-3 mt-4 text-[11px] leading-relaxed">
            <span className="font-mono uppercase font-bold text-stone-500 block mb-1">Active Slicers and Filter Matrix:</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono">
              <div>• Category: <strong className="text-stone-900">{filters.category || "All Categories"}</strong></div>
              <div>• Region: <strong className="text-stone-900">{filters.region || "All Regions"}</strong></div>
              <div>• Channel: <strong className="text-stone-900">{filters.channel || "All Channels"}</strong></div>
              <div>• Timeline: <strong className="text-stone-900">{filters.startDate || "Min Limit"}</strong> to <strong className="text-stone-900">{filters.endDate || "Max Limit"}</strong></div>
            </div>
          </div>
        </div>
        
        {/* 📚 Segment 1: Four KPI Metrics Cards Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <KpiCard
            id="kpi-revenue"
            title="Gross Revenue"
            value={`$${kpiStats.totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
            subtitle={`${kpiStats.totalQuantity.toLocaleString()} Total Units Handled`}
            icon={DollarSign}
            colorClass="bg-[#c5a059] text-[#c5a059]"
            trend={{ value: "+14.2%", isPositive: true }}
          />
          <KpiCard
            id="kpi-profit"
            title="Net Operations Profit"
            value={`$${kpiStats.totalProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
            subtitle="Calculated over production index"
            icon={FileCheck2}
            colorClass="bg-white text-white"
            trend={{ value: "+9.8%", isPositive: true }}
          />
          <KpiCard
            id="kpi-margin"
            title="Gross Margin Profile"
            value={`${kpiStats.avgMargin.toFixed(1)}%`}
            subtitle="Weighted aggregate margin"
            icon={Percent}
            colorClass="bg-[#888888] text-[#888888]"
            trend={{ value: "-1.1%", isPositive: false }}
          />
          <KpiCard
            id="kpi-orders"
            title="Average Ticket (AOV)"
            value={`$${kpiStats.avgOrderValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
            subtitle={`Across ${kpiStats.totalOrders} total invoices`}
            icon={ShoppingBag}
            colorClass="bg-[#444444] text-[#444444]"
            trend={{ value: "+2.4%", isPositive: true }}
          />
        </div>

        {/* 🌟 Interactive Client presentation & hotkey slideshow */}
        <div className="print:hidden">
          <ExecutiveSlideshow kpi={kpiStats} />
        </div>

        {/* 🛠️ Segment 2: Advanced Slicing Drill-down controls Bar */}
        <div className="print:hidden">
          <FiltersBar
            filters={filters}
            onChange={updateFilters}
            onReset={handleResetFilters}
            totalFilteredCount={filteredTransactions.length}
            totalCount={transactions.length}
          />
        </div>

        {viewMode === "dashboard" ? (
          <>
            {/* 🛡️ Segment 3: Gemini AI Advisory Core Intelligence Panel */}
            <AiAdvisor
              kpi={kpiStats}
              categoryData={categoryBreakdown}
              regionalData={regionalBreakdown}
              leaderboard={productLeaderboard}
              hasFilter={isFiltered}
            />

            {/* 📈 Segment 4: Dynamic SVG Area Plots & Category Progress Slices */}
            <InteractiveCharts
              monthlyTrends={monthlyTrends}
              categoryBreakdown={categoryBreakdown}
              regionalBreakdown={regionalBreakdown}
            />
          </>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <PowerBiSqlWorkspace transactions={filteredTransactions} />
          </motion.div>
        )}

        {/* 📋 Segment 5: Advanced Tables, CSV File importer matrices, and manual adder */}
        <TransactionsTable
          transactions={filteredTransactions}
          onAddTransaction={handleAddTransaction}
          onAddMultipleTransactions={handleAddMultipleTransactions}
          onDeleteTransaction={handleDeleteTransaction}
          onClearAll={handleClearAll}
        />
        
        {/* Additional information on features & evaluation parameters */}
        <div className="bg-[#0c0c0c] rounded-xl p-4 border border-[#1a1a1a] flex gap-3 items-start text-xs text-[#888] leading-relaxed print:hidden">
          <Info className="w-5 h-5 shrink-0 text-[#c5a059] mt-0.5" />
          <div>
            <strong>Evaluators & Managers Sandbox Guidelines</strong>: 
            Import custom rows from Excel or local reports using the <strong>Import CSV / Excel</strong> module inside the ledger panel. 
            All changes auto-save with client storage persistence. Filters, slicers, and trends recalculate immediately in-page.
            To test live AI business advice rendering, configure your <code>GEMINI_API_KEY</code> on the AI Studio panel.
          </div>
        </div>

      </main>

      {/* ☕ Humid footer with literal system details */}
      <footer className="mt-auto bg-[#0c0c0c] border-t border-[#1a1a1a] py-6 px-6 md:px-12 flex flex-col sm:flex-row items-center justify-between text-[#555] text-xs sm:gap-4 gap-2 print:hidden">
        <div>
          &copy; 2026 Sales & Revenue Control Workspace. All sandbox capabilities optimized.
        </div>
        <div className="flex items-center gap-4 text-[#888] font-serif italic text-xs">
          <span>Secure Client Sandboxed Environment</span>
        </div>
      </footer>
    </div>
  );
}
