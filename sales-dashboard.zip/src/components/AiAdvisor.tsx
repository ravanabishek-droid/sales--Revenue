/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { Sparkles, BrainCircuit, RefreshCw, Layers, CheckCircle2, AlertCircle } from "lucide-react";
import { KpiSummary, CategoryBreakdown, RegionalBreakdown, ProductLeaderboard } from "../types";

interface AiAdvisorProps {
  kpi: KpiSummary;
  categoryData: CategoryBreakdown[];
  regionalData: RegionalBreakdown[];
  leaderboard: ProductLeaderboard[];
  hasFilter: boolean;
}

/// Creative Native Markdown / Line Renderer to style the Gemini advisory beautifully
function ElegantMarkdown({ text }: { text: string }) {
  const lines = text.split("\n");
  return (
    <div className="space-y-3.5 text-[#ccc] leading-relaxed text-sm">
      {lines.map((line, idx) => {
        const trimmed = line.trim();

        // Headers
        if (trimmed.startsWith("###")) {
          return (
            <h4 key={idx} className="text-sm font-serif italic text-[#c5a059] tracking-tight pt-3 border-t border-[#1a1a1a] first:border-0 first:pt-0">
              {trimmed.replace(/^###\s*/, "")}
            </h4>
          );
        }
        if (trimmed.startsWith("####")) {
          return (
            <h5 key={idx} className="text-xs font-mono uppercase tracking-widest text-[#fff] pt-2">
              {trimmed.replace(/^####\s*/, "")}
            </h5>
          );
        }
        if (trimmed.startsWith("##") || trimmed.startsWith("#")) {
          return (
            <h3 key={idx} className="text-base font-serif text-white tracking-tight pt-4 border-b border-[#1a1a1a] pb-1">
              {trimmed.replace(/^#+\s*/, "")}
            </h3>
          );
        }

        // Bullets
        if (trimmed.startsWith("-") || trimmed.startsWith("*")) {
          const content = trimmed.replace(/^[-*]\s*/, "");
          return (
            <div key={idx} className="flex gap-2.5 items-start pl-2">
              <span className="text-[#c5a059] mt-1.5 shrink-0 block w-1.5 h-1.5 rounded-full bg-[#c5a059]"></span>
              <p className="flex-1 text-[#bbb]">
                {renderBoldTokens(content)}
              </p>
            </div>
          );
        }

        // Ordered list
        const olMatch = trimmed.match(/^(\d+)\.\s*(.*)/);
        if (olMatch) {
          const num = olMatch[1];
          const content = olMatch[2];
          return (
            <div key={idx} className="flex gap-2.5 items-start pl-2">
              <span className="text-[#c5a059] font-mono text-[10px] pb-0.5 mt-0.5 shrink-0 bg-[#111] border border-[#222] w-5 h-5 rounded flex items-center justify-center">
                {num}
              </span>
              <p className="flex-1 text-[#bbb]">
                {renderBoldTokens(content)}
              </p>
            </div>
          );
        }

        // Empty lines
        if (trimmed === "") {
          return <div key={idx} className="h-1" />;
        }

        // Regular paragraph with bold support
        return <p key={idx}>{renderBoldTokens(trimmed)}</p>;
      })}
    </div>
  );
}

// Inline token splitter for Bold formatting (**text**)
function renderBoldTokens(text: string) {
  const parts = text.split(/\*\*([^*]+)\*\*/g);
  if (parts.length === 1) return text;
  return parts.map((part, idx) => (idx % 2 === 1 ? <strong key={idx} className="font-semibold text-white">{part}</strong> : part));
}

export default function AiAdvisor({
  kpi,
  categoryData,
  regionalData,
  leaderboard,
  hasFilter
}: AiAdvisorProps) {
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<string | null>(null);
  const [isDemo, setIsDemo] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [loadingCaptionIdx, setLoadingCaptionIdx] = useState(0);

  const loadingCaptions = [
    "Compiling transaction aggregates and computing gross margin percentiles...",
    "Segmenting regional datasets under active sifting slices...",
    "Engaging server-side intelligence layers for expert analysis...",
    "Formatting direct corporate consulting strategies and action goals..."
  ];

  const triggerInsightsGeneration = async () => {
    setLoading(true);
    setReport(null);
    setErrorMsg("");
    setLoadingCaptionIdx(0);

    // Dynamic rotation of loading captions for immersive visual feedback
    const intervalTimer = setInterval(() => {
      setLoadingCaptionIdx((prev) => (prev + 1) % loadingCaptions.length);
    }, 1800);

    try {
      const response = await fetch("/api/insights", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          kpi,
          categoryData,
          regionalData,
          leaderboard,
          hasFilter
        })
      });

      if (!response.ok) {
        throw new Error(`Failed with server status: ${response.status}`);
      }

      const data = await response.json();
      setReport(data.insights);
      setIsDemo(!!data.isDemo);
    } catch (err: any) {
      console.error("AI Insights Trigger Failed:", err);
      setErrorMsg("Unable to retrieve automated recommendations. Make sure your server-side configuration is compiled.");
    } finally {
      clearInterval(intervalTimer);
      setLoading(false);
    }
  };

  return (
    <div id="ai-advisor-panel" className="bg-[#0c0c0c] border border-[#1a1a1a] rounded-xl p-6 text-[#dcdcdc]">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#1a1a1a] pb-4 mb-4">
        <div className="flex items-center gap-3">
          <div className="bg-[#111] p-2.5 rounded-lg border border-[#222]">
            <BrainCircuit className="w-5 h-5 text-[#c5a059]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-serif italic text-white">Gemini AI Executive Consultant</h3>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-[#111] border border-[#222] text-[#c5a059]">
                v3.5 Active
              </span>
            </div>
            <p className="text-xs text-[#888] mt-0.5">
              Instantly review top product performance models and receive consulting reports.
            </p>
          </div>
        </div>

        <button
          onClick={triggerInsightsGeneration}
          disabled={loading}
          className="bg-[#c5a059] hover:bg-[#d9b56d] text-black font-serif italic text-xs px-4 py-2.5 rounded-lg flex items-center justify-center gap-2 transition-all cursor-pointer select-none outline-hidden border border-transparent active:scale-98 disabled:opacity-40"
        >
          {loading ? (
            <RefreshCw className="w-3.5 h-3.5 animate-spin text-black" />
          ) : (
            <Sparkles className="w-3.5 h-3.5 text-black" />
          )}
          {report ? "Regenerate Intelligence Report" : "Generate Strategy Report"}
        </button>
      </div>

      {report && isDemo && (
        <div className="mb-4 bg-[#1a140a] border border-[#3d2f16] rounded-lg p-3 text-xs text-[#d9b56d] flex gap-2.5 items-start">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-[#c5a059]" />
          <div className="leading-relaxed font-mono text-[11px]">
            <strong>Demonstration Engine Engaged</strong>: Hook up a real 
            <code className="bg-[#241a0e] px-1 py-0.5 rounded text-white ml-1 border border-[#3d2f16]">GEMINI_API_KEY</code> in 
            the <strong>workspace environment</strong> to fetch bespoke strategies based on your filter states.
          </div>
        </div>
      )}

      {/* Main advisory content display */}
      {loading ? (
        <div className="py-12 flex flex-col items-center justify-center text-center gap-4">
          <div className="relative">
            <div className="w-10 h-10 rounded-full border-2 border-dashed border-[#c5a059]/40 border-t-[#c5a059] animate-spin"></div>
            <Sparkles className="absolute -top-1 -right-1 w-3.5 h-3.5 text-[#c5a059]" />
          </div>
          <div className="max-w-md">
            <p className="text-xs font-mono text-[#c5a059] tracking-tight">
              {loadingCaptions[loadingCaptionIdx]}
            </p>
            <p className="text-[10px] text-[#444] uppercase tracking-widest font-mono mt-1">
              Analyzing segment variances...
            </p>
          </div>
        </div>
      ) : report ? (
        <div className="bg-[#050505] rounded-lg p-5 text-[#dcdcdc] max-h-[480px] overflow-y-auto mt-2 border border-[#1a1a1a] transition-all">
          <ElegantMarkdown text={report} />
          <div className="mt-5 pt-3.5 border-t border-[#1a1a1a] flex items-center justify-between text-[11px] text-[#555] font-mono">
            <span>Report updated live</span>
            <span className="flex items-center gap-1 text-[#c5a059] font-serif italic text-xs">
              <CheckCircle2 className="w-3.5 h-3.5" /> Operations Alignment Stable
            </span>
          </div>
        </div>
      ) : errorMsg ? (
        <div className="bg-[#261515] border border-[#441a1a] p-4 rounded-lg text-rose-300 text-xs flex gap-2 items-center">
          <AlertCircle className="w-5 h-5 shrink-0 text-rose-450" />
          <span>{errorMsg}</span>
        </div>
      ) : (
        <div className="py-10 text-center flex flex-col items-center justify-center gap-3">
          <BrainCircuit className="w-8 h-8 text-[#333]" />
          <div className="max-w-md">
            <h4 className="text-xs font-serif italic text-white">No Advisory Report Compiled</h4>
            <p className="text-xs text-[#555] mt-1 leading-relaxed">
              Synthesize your segment metrics below by clicking Generate Strategy Report. 
              Our service maps custom units, channel spreads, and top items inside the active viewport filters.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
