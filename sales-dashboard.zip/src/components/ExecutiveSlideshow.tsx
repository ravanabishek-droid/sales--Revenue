/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, ChevronRight, Zap, Sparkles, Sliders, Award, Keyboard, CornerDownRight } from "lucide-react";
import { KpiSummary } from "../types";

interface ExecutiveSlideshowProps {
  kpi: KpiSummary;
}

export default function ExecutiveSlideshow({ kpi }: ExecutiveSlideshowProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const slides = [
    {
      id: "strategy-revenue",
      title: "Sovereign Growth Architecture",
      subtitle: "REAL-TIME FISCAL PERFORMANCE DECK",
      icon: Sparkles,
      color: "text-[#c5a059]",
      banner: "REVENUE ACCRETION",
      bgColor: "bg-radial from-[#c5a0590a] to-transparent",
      content: (
        <div className="flex flex-col md:flex-row items-center gap-6 justify-between h-full">
          <div className="flex-1 space-y-3">
            <div className="inline-flex items-center gap-1.5 bg-[#c5a05915] border border-[#c5a05933] px-2.5 py-0.5 rounded-full text-[9px] uppercase tracking-widest text-[#c5a059] font-mono">
              Market Acceleration
            </div>
            <h4 className="text-xl font-serif italic text-white">Capital Ledger Summary</h4>
            <p className="text-xs text-[#888] leading-relaxed max-w-lg font-sans">
              Operational channels are yielding a gross performance standing at{" "}
              <strong className="text-white font-mono">${kpi.totalRevenue.toLocaleString()}</strong>.
              Leveraging the AI Advisor sub-deck provides algorithmic guidance on cost reduction parameters 
              and dynamic ledger forecasting.
            </p>
            <div className="grid grid-cols-2 gap-3 pt-2">
              <div className="bg-[#080808] border border-[#161616] p-2 rounded-lg">
                <span className="text-[9px] uppercase tracking-wider text-[#555] font-mono block">Aggregate Volume</span>
                <span className="text-xs text-stone-200 font-mono font-medium">{kpi.totalQuantity.toLocaleString()} Units</span>
              </div>
              <div className="bg-[#080808] border border-[#161616] p-2 rounded-lg">
                <span className="text-[9px] uppercase tracking-wider text-[#555] font-mono block">Order Density</span>
                <span className="text-xs text-[#c5a059] font-mono font-medium">{kpi.totalOrders} Invoices</span>
              </div>
            </div>
          </div>
          <div className="flex-shrink-0 w-full md:w-56 bg-gradient-to-br from-[#0c0c0c] to-[#040404] border border-[#1c1c1c] p-4 rounded-xl flex flex-col justify-between h-full relative overflow-hidden group">
            <span className="absolute -top-10 -right-10 w-24 h-24 bg-[#c5a059] opacity-5 rounded-full blur-xl group-hover:opacity-10 transition-all duration-700"></span>
            <div>
              <span className="text-[9px] font-mono uppercase tracking-widest text-[#555] block">Current Scale</span>
              <div className="text-2xl font-mono font-bold text-white mt-1">
                ${(kpi.totalRevenue / 1000).toFixed(1)}k
              </div>
            </div>
            <div className="border-t border-[#161616] pt-2 mt-4 flex items-center justify-between">
              <span className="text-[9px] text-[#555]">Operational Health</span>
              <span className="text-[10px] text-[#c5a059] font-serif italic">Nominal Standing</span>
            </div>
          </div>
        </div>
      ),
    },
    {
      id: "strategy-profitability",
      title: "Executive Margin Calibration",
      subtitle: "FISCAL OPTIMIZATION DECK",
      icon: Award,
      color: "text-white",
      banner: "MARGIN HARVESTING",
      bgColor: "bg-radial from-[#ffffff06] to-transparent",
      content: (
        <div className="flex flex-col md:flex-row items-center gap-6 justify-between h-full">
          <div className="flex-1 space-y-3">
            <div className="inline-flex items-center gap-1.5 bg-white/5 border border-white/10 px-2.5 py-0.5 rounded-full text-[9px] uppercase tracking-widest text-[#bbb] font-mono">
              Profit Optimization
            </div>
            <h4 className="text-xl font-serif italic text-white">Sovereign Asset Conversion</h4>
            <p className="text-xs text-[#888] leading-relaxed max-w-lg font-sans">
              The sovereign enterprise maintains a robust profit standing of{" "}
              <strong className="text-white font-mono">${kpi.totalProfit.toLocaleString()}</strong>, 
              translating to a weighted average performance margin of{" "}
              <strong className="text-white font-mono">{kpi.avgMargin.toFixed(1)}%</strong>. 
              Calibrating product channels to focus on high-margin items reduces systemic dependencies.
            </p>
            <div className="flex items-center gap-4 pt-1">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#c5a059]"></span>
                <span className="text-[10px] text-stone-400 font-mono">High Margin Channel Strategy</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-stone-500"></span>
                <span className="text-[10px] text-stone-400 font-mono">Dynamic Cost Regulation</span>
              </div>
            </div>
          </div>
          <div className="w-full md:w-56 bg-neutral-950 border border-[#1c1c1c] p-4 rounded-xl flex flex-col justify-between h-full relative overflow-hidden group">
            <div className="space-y-1">
              <span className="text-[9px] font-mono uppercase tracking-widest text-[#555] block">Average Margin Target</span>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-mono font-bold text-[#c5a059]">{kpi.avgMargin.toFixed(1)}%</span>
                <span className="text-[9px] text-emerald-500 font-mono">Level ✅</span>
              </div>
            </div>
            <div className="w-full bg-[#111] h-1.5 rounded-full overflow-hidden mt-3.5 border border-[#222]">
              <div 
                className="bg-gradient-to-r from-stone-500 to-[#c5a059] h-full rounded-full" 
                style={{ width: `${Math.min(kpi.avgMargin, 100)}%` }}
              ></div>
            </div>
            <div className="text-[8px] text-[#555] font-mono text-center mt-2 uppercase tracking-wider">
              {kpi.avgMargin > 40 ? "Excellent Margin Standing" : "Calibrated Baseline"}
            </div>
          </div>
        </div>
      ),
    },
    {
      id: "productivity-hotkeys",
      title: "Sovereign Workspace Hotkeys",
      subtitle: "PRODUCTIVITY COMMAND HUB",
      icon: Keyboard,
      color: "text-amber-500",
      banner: "OPERATIONAL AGILITY",
      bgColor: "bg-radial from-[#c5a0590c] to-transparent",
      content: (
        <div className="flex flex-col md:flex-row items-center gap-6 justify-between h-full">
          <div className="flex-1 space-y-3">
            <div className="inline-flex items-center gap-1.5 bg-[#c5a05910] border border-[#c5a05922] px-2.5 py-0.5 rounded-full text-[9px] uppercase tracking-widest text-[#c5a059] font-mono">
              Keyboard Agility
            </div>
            <h4 className="text-xl font-serif italic text-white">Command Deck Shortcut Arrays</h4>
            <p className="text-xs text-[#888] leading-relaxed max-w-lg font-sans">
              Enhance command desk speed via standard local keystroke short-circuits. 
              Control search profiles, resets, and add transaction modals instantaneously without pointing.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 font-mono">
              <div 
                onClick={() => window.dispatchEvent(new CustomEvent("toggle-add-sale-form"))}
                className="flex items-center justify-between p-2 rounded bg-[#0a0a0a] border border-[#1a1a1a] cursor-pointer hover:border-[#c5a05944] active:scale-95 transition-all"
              >
                <div className="flex items-center gap-1.5 text-xs text-stone-300">
                  <CornerDownRight className="w-3 h-3 text-[#c5a059]" />
                  <span>Log New Sale</span>
                </div>
                <kbd className="px-1.5 py-0.5 bg-[#111] border border-[#222] text-[#c5a059] text-[9px] font-sans font-bold rounded">Alt + N</kbd>
              </div>
              <div 
                onClick={() => window.dispatchEvent(new CustomEvent("toggle-add-sale-form"))}
                className="flex items-center justify-between p-2 rounded bg-[#0a0a0a] border border-[#1a1a1a] cursor-pointer hover:border-[#c5a05944] active:scale-95 transition-all"
              >
                <div className="flex items-center gap-1.5 text-xs text-stone-300">
                  <CornerDownRight className="w-3 h-3 text-[#c5a059]" />
                  <span>Clear Filter Array</span>
                </div>
                <kbd className="px-1.5 py-0.5 bg-[#111] border border-[#222] text-[#c5a059] text-[9px] font-sans font-bold rounded">Alt + R</kbd>
              </div>
            </div>
          </div>
          <div className="hidden md:flex flex-col justify-center items-center w-52 border border-[#1c1c1c] bg-[#0c0c0c] p-4 rounded-xl text-center h-full">
            <span className="text-[10px] text-[#555] font-mono uppercase tracking-widest">Efficiency Multiplier</span>
            <div className="text-3xl font-serif italic text-white mt-1">2.4x</div>
            <p className="text-[9px] text-[#444] mt-1 font-sans leading-relaxed">
              Standardized key mappings reduce mouse hover latencies by up to 140ms per interaction.
            </p>
          </div>
        </div>
      ),
    },
  ];

  // Auto-play routine
  useEffect(() => {
    if (!isAutoPlaying) return;
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 8500);
    return () => clearInterval(interval);
  }, [isAutoPlaying, slides.length]);

  const handlePrev = () => {
    setIsAutoPlaying(false);
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const handleNext = () => {
    setIsAutoPlaying(false);
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const IconComponent = slides[currentSlide].icon;

  return (
    <div 
      className="bg-[#0c0c0c] border border-[#1a1a1a] rounded-xl p-6 relative overflow-hidden flex flex-col justify-between min-h-[220px]"
      onMouseEnter={() => setIsAutoPlaying(false)}
      onMouseLeave={() => setIsAutoPlaying(true)}
      id="executive-slide-show-panel"
    >
      {/* Background ambient lighting */}
      <div className={`absolute inset-0 transition-all duration-1000 ${slides[currentSlide].bgColor}`}></div>

      {/* Top Banner Slide Info */}
      <div className="relative z-10 flex items-center justify-between border-b border-[#111] pb-3 mb-4">
        <div className="flex items-center gap-2">
          <IconComponent className={`w-4 h-4 ${slides[currentSlide].color}`} />
          <div>
            <span className="text-[9px] font-mono uppercase tracking-widest text-[#555] block leading-none">
              {slides[currentSlide].subtitle}
            </span>
            <h3 className="text-xs uppercase tracking-wider font-mono text-[#c5a059] mt-0.5 leading-none">
              {slides[currentSlide].title}
            </h3>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button 
            onClick={handlePrev}
            className="p-1 rounded bg-[#111] border border-[#1d1d1d] hover:border-[#c5a05944] text-[#555] hover:text-white transition-all cursor-pointer"
            title="Previous Slide"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <div className="flex items-center gap-1 mx-2">
            {slides.map((_, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setIsAutoPlaying(false);
                  setCurrentSlide(idx);
                }}
                className={`w-1.5 h-1.5 rounded-full transition-all ${
                  idx === currentSlide ? "bg-[#c5a059] scale-125" : "bg-[#222]"
                }`}
                title={`Slide ${idx + 1}`}
              ></button>
            ))}
          </div>
          <button 
            onClick={handleNext}
            className="p-1 rounded bg-[#111] border border-[#1d1d1d] hover:border-[#c5a05944] text-[#555] hover:text-white transition-all cursor-pointer"
            title="Next Slide"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Slide Transition Canvas Area */}
      <div className="relative z-10 flex-1 min-h-[120px]">
        <AnimatePresence mode="wait">
          <motion.div
            key={slides[currentSlide].id}
            initial={{ opacity: 0, x: 15 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -15 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
            className="h-full"
          >
            {slides[currentSlide].content}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Slide decoration lines */}
      <span className="absolute bottom-0 left-0 h-0.5 bg-[#c5a059] transition-all duration-[8500ms] ease-linear"
        style={{ width: isAutoPlaying ? "100%" : "0%" }}
        key={`${currentSlide}-${isAutoPlaying}`}
      ></span>
    </div>
  );
}
