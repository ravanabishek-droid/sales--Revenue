/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Search, Calendar, Filter, RotateCcw } from "lucide-react";
import { DashboardFilters } from "../types";
import { CATEGORIES, REGIONS, CHANNELS, PAYMENT_METHODS } from "../data";

interface FiltersBarProps {
  filters: DashboardFilters;
  onChange: (updated: Partial<DashboardFilters>) => void;
  onReset: () => void;
  totalFilteredCount: number;
  totalCount: number;
}

export default function FiltersBar({
  filters,
  onChange,
  onReset,
  totalFilteredCount,
  totalCount
}: FiltersBarProps) {
  // Common Date Presets
  const applyPreset = (range: "all" | "q1" | "q2" | "h1") => {
    switch (range) {
      case "all":
        onChange({ startDate: "", endDate: "" });
        break;
      case "q1":
        onChange({ startDate: "2026-01-01", endDate: "2026-03-31" });
        break;
      case "q2":
        onChange({ startDate: "2026-04-01", endDate: "2026-06-30" });
        break;
      case "h1":
        onChange({ startDate: "2026-01-01", endDate: "2026-06-30" });
        break;
    }
  };

  return (
    <div className="bg-[#0c0c0c] border border-[#1a1a1a] rounded-xl p-5 flex flex-col gap-4 text-[#dcdcdc]">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-[#c5a059]" />
          <h2 className="text-sm font-serif italic text-white">Segment & Filter Records</h2>
          <span className="text-[10px] bg-[#111] border border-[#222] text-[#c5a059] px-2 py-0.5 rounded font-mono">
            {totalFilteredCount} of {totalCount} records
          </span>
        </div>

        {/* Quick Date Presets */}
        <div className="flex flex-wrap gap-1.5 items-center">
          <span className="text-[10px] uppercase tracking-widest text-[#444] mr-1.5">Quick Ranges:</span>
          {[
            { label: "All Time", value: "all" as const },
            { label: "Q1 2026", value: "q1" as const },
            { label: "Q2 2026", value: "q2" as const },
            { label: "H1 2026", value: "h1" as const }
          ].map((preset) => (
            <button
              key={preset.value}
              onClick={() => applyPreset(preset.value)}
              className="text-[10px] uppercase tracking-wider font-mono px-2.5 py-1 rounded bg-[#111] border border-[#1a1a1a] hover:border-[#c5a05933] text-[#888] hover:text-white transition-all cursor-pointer"
            >
              {preset.label}
            </button>
          ))}
          <button
            onClick={onReset}
            className="text-[10px] uppercase tracking-wider font-mono px-2.5 py-1 rounded bg-[#2b1616] border border-[#441a1a] text-rose-400 hover:bg-[#3d1a1a] transition-colors ml-auto lg:ml-0 cursor-pointer flex items-center gap-1"
          >
            Reset Filters
            <kbd className="hidden sm:inline-block ml-1.5 px-1 py-0.2 rounded bg-[#1a0a0a] text-rose-300/80 text-[8px] font-sans border border-rose-900/30">Alt+R</kbd>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Search Input */}
        <div className="relative">
          <label className="block text-[10px] uppercase tracking-widest text-[#555] mb-1.5 font-mono">
            Search Product / invoice
          </label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500 fill-transparent" />
            <input
              type="text"
              value={filters.searchQuery}
              onChange={(e) => onChange({ searchQuery: e.target.value })}
              placeholder="e.g. Laptop, INV-1001..."
              className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-[#1a1a1a] focus:border-[#c5a05955] bg-[#050505] focus:outline-hidden text-xs text-white placeholder-[#444] transition-all"
            />
          </div>
        </div>

        {/* Start & End Dates */}
        <div>
          <label className="block text-[10px] uppercase tracking-widest text-[#555] mb-1.5 font-mono mr-1">
            Date Range (Start - End)
          </label>
          <div className="grid grid-cols-2 gap-2">
            <div className="relative">
              <Calendar className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500 pointer-events-none" />
              <input
                type="date"
                value={filters.startDate}
                onChange={(e) => onChange({ startDate: e.target.value })}
                className="w-full pl-8 pr-1.5 py-1.5 rounded-lg border border-[#1a1a1a] focus:border-[#c5a05955] bg-[#050505] focus:outline-hidden text-[10px] text-white transition-all scheme-dark"
              />
            </div>
            <div className="relative">
              <Calendar className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-500 pointer-events-none" />
              <input
                type="date"
                value={filters.endDate}
                onChange={(e) => onChange({ endDate: e.target.value })}
                className="w-full pl-8 pr-1.5 py-1.5 rounded-lg border border-[#1a1a1a] focus:border-[#c5a05955] bg-[#050505] focus:outline-hidden text-[10px] text-white transition-all scheme-dark"
              />
            </div>
          </div>
        </div>

        {/* Category & Region Slicers */}
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="block text-[10px] uppercase tracking-widest text-[#555] mb-1.5 font-mono">
              Category
            </label>
            <select
              value={filters.category}
              onChange={(e) => onChange({ category: e.target.value })}
              className="w-full px-2 py-1.5 rounded-lg border border-[#1a1a1a] focus:border-[#c5a05955] bg-[#050505] focus:outline-hidden text-xs text-white transition-all cursor-pointer"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat} className="bg-neutral-950 text-white">
                  {cat === "All" ? "All Categories" : cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] uppercase tracking-widest text-[#555] mb-1.5 font-mono">
              Region
            </label>
            <select
              value={filters.region}
              onChange={(e) => onChange({ region: e.target.value })}
              className="w-full px-2 py-1.5 rounded-lg border border-[#1a1a1a] focus:border-[#c5a05955] bg-[#050505] focus:outline-hidden text-xs text-white transition-all cursor-pointer"
            >
              {REGIONS.map((reg) => (
                <option key={reg} value={reg} className="bg-neutral-950 text-white">
                  {reg === "All" ? "All Regions" : reg}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Channel & Payment Slicers */}
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="block text-[10px] uppercase tracking-widest text-[#555] mb-1.5 font-mono">
              Channel
            </label>
            <select
              value={filters.channel}
              onChange={(e) => onChange({ channel: e.target.value })}
              className="w-full px-2 py-1.5 rounded-lg border border-[#1a1a1a] focus:border-[#c5a05955] bg-[#050505] focus:outline-hidden text-xs text-white transition-all cursor-pointer"
            >
              {CHANNELS.map((ch) => (
                <option key={ch} value={ch} className="bg-neutral-950 text-white">
                  {ch === "All" ? "All Channels" : ch}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] uppercase tracking-widest text-[#555] mb-1.5 font-mono">
              Payment
            </label>
            <select
              value={filters.paymentMethod}
              onChange={(e) => onChange({ paymentMethod: e.target.value })}
              className="w-full px-2 py-1.5 rounded-lg border border-[#1a1a1a] focus:border-[#c5a05955] bg-[#050505] focus:outline-hidden text-xs text-white transition-all cursor-pointer"
            >
              {PAYMENT_METHODS.map((pm) => (
                <option key={pm} value={pm} className="bg-neutral-950 text-white">
                  {pm === "All" ? "All Methods" : pm}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}
