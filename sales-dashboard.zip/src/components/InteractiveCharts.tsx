/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { DollarSign, Landmark, Layers, ShoppingBag } from "lucide-react";
import { MonthlyTrend, CategoryBreakdown, RegionalBreakdown } from "../types";

interface InteractiveChartsProps {
  monthlyTrends: MonthlyTrend[];
  categoryBreakdown: CategoryBreakdown[];
  regionalBreakdown: RegionalBreakdown[];
}

export default function InteractiveCharts({
  monthlyTrends,
  categoryBreakdown,
  regionalBreakdown
}: InteractiveChartsProps) {
  const [hoveredTrendIdx, setHoveredTrendIdx] = useState<number | null>(null);
  const [hoveredCatKey, setHoveredCatKey] = useState<string | null>(null);

  // Calculate average monthly revenue to set realistic, progressive historical targets
  const avgMonthlyRevenue = monthlyTrends.length > 0
    ? monthlyTrends.reduce((sum, t) => sum + t.revenue, 0) / monthlyTrends.length
    : 12000;

  // Progressive strategic sovereign target line representing monthly target milestones
  const getTargetVal = (idx: number) => {
    return Math.max(1000, Math.round(avgMonthlyRevenue * (0.92 + idx * 0.035)));
  };

  // 1. Calculations for Monthly Trend Scaling (accounting for targets, profit, and revenue)
  const maxMonthlyVal = Math.max(
    ...monthlyTrends.map((t, idx) => Math.max(t.revenue, t.profit, getTargetVal(idx))),
    5000
  );

  // SVG dimensions
  const svgWidth = 500;
  const svgHeight = 200;
  const paddingX = 40;
  const paddingY = 20;

  const chartWidth = svgWidth - paddingX * 2;
  const chartHeight = svgHeight - paddingY * 2;

  // Format Month Label helper (e.g., "2026-01" -> "Jan 26")
  const formatMonth = (monthStr: string) => {
    const parts = monthStr.split("-");
    if (parts.length < 2) return monthStr;
    const monthIndex = parseInt(parts[1], 10) - 1;
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return `${months[monthIndex]} '${parts[0].slice(2)}`;
  };

  // Generate SVG Points for Revenue and Profit Area
  const getPoints = (isRevenue: boolean) => {
    if (monthlyTrends.length === 0) return "";
    return monthlyTrends
      .map((t, idx) => {
        const x = paddingX + (idx / Math.max(monthlyTrends.length - 1, 1)) * chartWidth;
        const val = isRevenue ? t.revenue : t.profit;
        const y = paddingY + chartHeight - (val / maxMonthlyVal) * chartHeight;
        return `${x},${y}`;
      })
      .join(" ");
  };

  const getTargetPoints = () => {
    if (monthlyTrends.length === 0) return "";
    return monthlyTrends
      .map((t, idx) => {
        const x = paddingX + (idx / Math.max(monthlyTrends.length - 1, 1)) * chartWidth;
        const val = getTargetVal(idx);
        const y = paddingY + chartHeight - (val / maxMonthlyVal) * chartHeight;
        return `${x},${y}`;
      })
      .join(" ");
  };

  const revenuePoints = getPoints(true);
  const profitPoints = getPoints(false);
  const targetPoints = getTargetPoints();

  // Close the area path for elegant background fills
  const revenueAreaPoints = revenuePoints
    ? `${paddingX},${paddingY + chartHeight} ${revenuePoints} ${
        paddingX + chartWidth
      },${paddingY + chartHeight}`
    : "";

  const profitAreaPoints = profitPoints
    ? `${paddingX},${paddingY + chartHeight} ${profitPoints} ${
        paddingX + chartWidth
      },${paddingY + chartHeight}`
    : "";

  // 2. Category Color Mapping Helper with premium Sophisticated tones
  const getCategoryColor = (cat: string) => {
    switch (cat.toLowerCase()) {
      case "electronics":
        return { bg: "bg-[#c5a059]", text: "text-[#c5a059]", raw: "#c5a059" };
      case "office supplies":
        return { bg: "bg-[#a68444]", text: "text-[#a68444]", raw: "#a68444" };
      case "fitness & sport":
        return { bg: "bg-white", text: "text-white", raw: "#ffffff" };
      case "home & kitchen":
        return { bg: "bg-[#888888]", text: "text-[#888888]", raw: "#888888" };
      case "apparel":
        return { bg: "bg-[#444444]", text: "text-[#444444]", raw: "#444444" };
      default:
        return { bg: "bg-[#555555]", text: "text-[#555555]", raw: "#555555" };
    }
  };

  // Total Revenue among Categories for relative percentage metrics
  const totalCatRevenue = categoryBreakdown.reduce((acc, curr) => acc + curr.revenue, 0);
  const totalRegRevenue = regionalBreakdown.reduce((acc, curr) => acc + curr.revenue, 0);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Chart 1: Revenue & Profit Monthly Timeline Area Graph */}
      <div className="lg:col-span-2 bg-[#0c0c0c] border border-[#1a1a1a] rounded-xl p-5 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Landmark className="w-4 h-4 text-[#c5a059]" />
              <h3 className="text-sm font-serif italic text-white flex items-center gap-1">Operational Revenue & Profit Trend</h3>
            </div>
            {/* Visual Legends */}
            <div className="flex items-center gap-4 text-[10px]">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-[#c5a059] inline-block"></span>
                <span className="text-[#888] font-medium">Revenue</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-[#888] inline-block"></span>
                <span className="text-[#888] font-medium">Net Profit</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-px border-t border-dashed border-[#c5a059] opacity-80 inline-block"></span>
                <span className="text-[#888] font-medium">Target Bench</span>
              </div>
            </div>
          </div>
          <p className="text-[11px] text-[#555] mt-1">
            Timeline plots showing performance. Hover markers for exact values.
          </p>
        </div>

        {monthlyTrends.length === 0 ? (
          <div className="h-44 flex items-center justify-center border border-dashed border-[#222] rounded-lg my-4">
            <span className="text-xs text-[#555]">No date range transactions to plot.</span>
          </div>
        ) : (
          <div className="relative mt-4">
            <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-auto overflow-visible select-none">
              {/* Horizontal Reference Gridlines */}
              {[0, 0.25, 0.5, 0.75, 1].map((ratio, index) => {
                const y = paddingY + chartHeight * ratio;
                const value = maxMonthlyVal * (1 - ratio);
                return (
                  <g key={index} className="opacity-60">
                    <line
                      x1={paddingX}
                      y1={y}
                      x2={paddingX + chartWidth}
                      y2={y}
                      stroke="#1d1d1d"
                      strokeWidth="1"
                    />
                    <text
                      x={paddingX - 8}
                      y={y + 3}
                      className="text-[8px] fill-[#444] font-mono text-end"
                      textAnchor="end"
                    >
                      ${value >= 1000 ? `${(value / 1000).toFixed(1)}k` : value.toFixed(0)}
                    </text>
                  </g>
                );
              })}

              {/* Revenue Area Fill & Line */}
              {revenueAreaPoints && (
                <polygon points={revenueAreaPoints} fill="url(#revenueGrad)" opacity="0.3" />
              )}
              {revenuePoints && (
                <polyline points={revenuePoints} fill="none" stroke="#c5a059" strokeWidth="2" />
              )}

              {/* Profit Area Fill & Line */}
              {profitAreaPoints && (
                <polygon points={profitAreaPoints} fill="url(#profitGrad)" opacity="0.15" />
              )}
              {profitPoints && (
                <polyline points={profitPoints} fill="none" stroke="#888888" strokeWidth="1.5" />
              )}

              {/* Sovereign Target Benchmark dashed line */}
              {targetPoints && (
                <polyline 
                  points={targetPoints} 
                  fill="none" 
                  stroke="#c5a059" 
                  strokeWidth="1.2" 
                  strokeDasharray="4,3" 
                  opacity="0.6" 
                />
              )}

              {/* Dynamic Interactive Node Circles on Hover */}
              {monthlyTrends.map((t, idx) => {
                const x = paddingX + (idx / Math.max(monthlyTrends.length - 1, 1)) * chartWidth;
                const yRev = paddingY + chartHeight - (t.revenue / maxMonthlyVal) * chartHeight;
                const yProf = paddingY + chartHeight - (t.profit / maxMonthlyVal) * chartHeight;
                const yTarget = paddingY + chartHeight - (getTargetVal(idx) / maxMonthlyVal) * chartHeight;
                const isHovered = hoveredTrendIdx === idx;

                return (
                  <g key={idx}>
                    {/* Hover hotspot column */}
                    <rect
                      x={x - chartWidth / (monthlyTrends.length * 2)}
                      y={paddingY}
                      width={chartWidth / Math.max(monthlyTrends.length - 1, 1)}
                      height={chartHeight}
                      fill="transparent"
                      className="cursor-pointer"
                      onMouseEnter={() => setHoveredTrendIdx(idx)}
                      onMouseLeave={() => setHoveredTrendIdx(null)}
                    />

                    {/* Anchor dots */}
                    <circle
                      cx={x}
                      cy={yRev}
                      r={isHovered ? 4.5 : 3}
                      className="fill-[#c5a059] stroke-[#0c0c0c] cursor-pointer"
                      strokeWidth={1}
                    />
                    <circle
                      cx={x}
                      cy={yProf}
                      r={isHovered ? 4 : 2.5}
                      className="fill-[#888888] stroke-[#0c0c0c] cursor-pointer"
                      strokeWidth={1}
                    />
                    <circle
                      cx={x}
                      cy={yTarget}
                      r={isHovered ? 4.5 : 2}
                      className="fill-[#0c0c0c] stroke-[#c5a059] stroke-[1] cursor-pointer"
                      strokeWidth={isHovered ? 1.5 : 1}
                      strokeDasharray={isHovered ? "none" : "2,1"}
                    />

                    {/* Month text label on X Axis */}
                    <text
                      x={x}
                      y={paddingY + chartHeight + 14}
                      className={`text-[8px] font-mono transition-all text-center fill-[#444] ${
                        isHovered ? "font-bold fill-[#c5a059]" : ""
                      }`}
                      textAnchor="middle"
                    >
                      {formatMonth(t.month)}
                    </text>
                  </g>
                );
              })}

              {/* SVG Gradient Declarations */}
              <defs>
                <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#c5a059" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#c5a059" stopOpacity="0" />
                </linearGradient>
                <linearGradient id="profitGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#888888" stopOpacity="0.2" />
                  <stop offset="100%" stopColor="#888888" stopOpacity="0" />
                </linearGradient>
              </defs>
            </svg>

            {/* Dynamic Card HTML Tooltip aligned to hover index */}
            {hoveredTrendIdx !== null && monthlyTrends[hoveredTrendIdx] && (() => {
              const currentRev = monthlyTrends[hoveredTrendIdx].revenue;
              const currentTarget = getTargetVal(hoveredTrendIdx);
              const variance = currentRev - currentTarget;
              const variancePct = ((variance / (currentTarget || 1)) * 100);
              const isPositive = variance >= 0;

              return (
                <div className="absolute top-2 left-1/2 -translate-x-1/2 bg-[#050505] text-[#dcdcdc] p-3 rounded border border-[#222] text-xs flex flex-col gap-1.5 z-10 pointer-events-none min-w-[160px] shadow-2xl">
                  <div className="font-serif italic text-[#c5a059] border-b border-[#1a1a1a] pb-1 text-center text-[11px]">
                    {formatMonth(monthlyTrends[hoveredTrendIdx].month)}
                  </div>
                  <div className="flex justify-between gap-4 mt-0.5 font-mono text-[10px]">
                    <span>Revenue:</span>
                    <span className="font-semibold text-white">
                      ${currentRev.toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })}
                    </span>
                  </div>
                  <div className="flex justify-between gap-4 font-mono text-[10px]">
                    <span>Net Profit:</span>
                    <span className="font-semibold text-stone-300">
                      ${monthlyTrends[hoveredTrendIdx].profit.toLocaleString(undefined, {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                      })}
                    </span>
                  </div>
                  <div className="flex justify-between gap-4 font-mono text-[10px] border-t border-[#1a1a1a]/45 pt-1">
                    <span>Target:</span>
                    <span className="font-semibold text-[#c5a059]/80">
                      ${currentTarget.toLocaleString(undefined, {
                        minimumFractionDigits: 0,
                        maximumFractionDigits: 0
                      })}
                    </span>
                  </div>
                  <div className="flex justify-between gap-4 font-mono text-[9px]">
                    <span>Variance:</span>
                    <span className={`font-semibold ${isPositive ? "text-emerald-400" : "text-rose-400"}`}>
                      {isPositive ? "+" : ""}{variancePct.toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex justify-between gap-4 border-t border-[#1a1a1a] pt-1 text-[9px] font-mono text-[#888]">
                    <span>Unit Volume:</span>
                    <span className="font-semibold text-white">
                      {monthlyTrends[hoveredTrendIdx].units.toLocaleString()} units
                    </span>
                  </div>
                  <div className="flex justify-between gap-4 text-[9px] font-mono text-[#c5a059]">
                    <span>Profit Margin %:</span>
                    <span className="font-bold">
                      {(
                        (monthlyTrends[hoveredTrendIdx].profit /
                          (currentRev || 1)) *
                        100
                      ).toFixed(1)}
                      %
                    </span>
                  </div>
                </div>
              );
            })()}
          </div>
        )}
      </div>

      {/* Chart 2: Product Category Slices / Segments */}
      <div className="bg-[#0c0c0c] border border-[#1a1a1a] rounded-xl p-5 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#c5a059]" />
            <h3 className="text-sm font-serif italic text-white">Category Share & Margin</h3>
          </div>
          <p className="text-[11px] text-[#555] mt-1">
            Segment revenue contribution against margins.
          </p>
        </div>

        {categoryBreakdown.length === 0 ? (
          <div className="h-44 flex items-center justify-center border border-dashed border-[#222] rounded-lg">
            <span className="text-xs text-[#555]">No segmented category data.</span>
          </div>
        ) : (
          <div className="flex flex-col gap-4 mt-4">
            {categoryBreakdown.map((cat) => {
              const share = totalCatRevenue > 0 ? (cat.revenue / totalCatRevenue) * 100 : 0;
              const margin = cat.revenue > 0 ? (cat.profit / cat.revenue) * 100 : 0;
              const theme = getCategoryColor(cat.category);

              return (
                <div 
                  key={cat.category} 
                  className="flex flex-col gap-1 p-2 -mx-2 rounded-lg hover:bg-[#111] transition-all duration-200 group/cat cursor-pointer relative"
                  onMouseEnter={() => setHoveredCatKey(cat.category)}
                  onMouseLeave={() => setHoveredCatKey(null)}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-stone-300 font-serif italic truncate max-w-[140px] group-hover/cat:text-[#c5a059] transition-colors">
                      {cat.category}
                    </span>
                    <span className="font-mono text-[#888] text-[11px] group-hover/cat:text-white transition-colors">
                      ${cat.revenue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </span>
                  </div>

                  {/* Relative Segment bar with modern trace styling */}
                  <div className="w-full bg-[#111] border border-[#222] rounded-full h-1.5 overflow-hidden relative">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${theme.bg}`}
                      style={{ width: `${share}%` }}
                    ></div>
                  </div>

                  {/* Profit margin tag and share percent */}
                  <div className="flex items-center justify-between text-[9px] text-[#555] font-mono group-hover/cat:text-stone-300 transition-colors">
                    <span>{share.toFixed(0)}% revenue share</span>
                    <span className="text-[#c5a059] bg-[#c5a05911] px-1 py-0.2 rounded border border-[#c5a05922] font-semibold">
                      {margin.toFixed(1)}% Profit Margin
                    </span>
                  </div>

                  {/* Floating micro-panel hover overlay details */}
                  {hoveredCatKey === cat.category && (
                    <div className="absolute bottom-full mb-1 left-5 bg-[#050505] text-[#dcdcdc] p-2.5 rounded border border-[#222] text-[10px] flex flex-col gap-1 z-20 pointer-events-none min-w-[170px] shadow-2xl font-mono">
                      <div className="font-serif italic text-[#c5a059] border-b border-[#111] pb-1 text-center font-bold">
                        {cat.category} Details
                      </div>
                      <div className="flex justify-between gap-4 mt-1">
                        <span className="text-stone-400">Unit Volume:</span>
                        <span className="font-semibold text-white">{cat.units.toLocaleString()} units</span>
                      </div>
                      <div className="flex justify-between gap-4">
                        <span className="text-stone-400">Profit Margin %:</span>
                        <span className="font-semibold text-[#c5a059]">{margin.toFixed(1)}%</span>
                      </div>
                      <div className="flex justify-between gap-4">
                        <span className="text-stone-400">Net Profit:</span>
                        <span className="font-semibold text-[#888]">${cat.profit.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Chart 3: Regional Sales Leaderboard Column bar proportional representation */}
      <div className="lg:col-span-3 bg-[#0c0c0c] border border-[#1a1a1a] rounded-xl p-5 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-[#c5a059]" />
              <h3 className="text-sm font-serif italic text-white">Geographical Markets Standing</h3>
            </div>
          </div>
          <p className="text-[11px] text-[#555] mt-1">
            Global density breakdown reflecting aggregate sales.
          </p>
        </div>

        {regionalBreakdown.length === 0 ? (
          <div className="h-24 flex items-center justify-center">
            <span className="text-xs text-[#555]">No regional indicators configured.</span>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4">
            {regionalBreakdown.map((reg, index) => {
              const pct = totalRegRevenue > 0 ? (reg.revenue / totalRegRevenue) * 100 : 0;
              const margin = reg.revenue > 0 ? (reg.profit / reg.revenue) * 100 : 0;
              return (
                <div 
                  key={reg.region} 
                  className="bg-[#050505] rounded-xl p-3 border border-[#1a1a1a] flex flex-col justify-between overflow-hidden relative group hover:border-[#c5a059bb] hover:shadow-[0_0_15px_rgba(197,160,89,0.05)] transition-all duration-300 select-none min-h-[96px]"
                >
                  {/* Subtle Accent slide */}
                  <div className="absolute top-0 left-0 w-1 h-full bg-[#c5a059] group-hover:w-full group-hover:opacity-[0.02] transition-all duration-300"></div>
                  
                  {/* Default Info */}
                  <div className="transition-all duration-300 group-hover:opacity-10 group-hover:scale-95">
                    <div className="text-[9px] uppercase font-mono tracking-widest text-[#555] truncate">
                      {reg.region}
                    </div>
                    <div className="mt-2">
                      <div className="text-sm font-serif text-white">
                        ${reg.revenue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </div>
                      <div className="text-[9px] font-mono text-[#555] mt-1">
                        {reg.units.toLocaleString()} units ({pct.toFixed(0)}%)
                      </div>
                    </div>
                  </div>

                  {/* Hover HUD Tooltip (Reveals exact granular statistics) */}
                  <div className="absolute inset-0 p-3 flex flex-col justify-between bg-[#080808] opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none font-mono text-[9px]">
                    <div className="border-b border-[#1b1b1b] pb-1 font-serif italic truncate text-[#c5a059]">
                      {reg.region} Metrics
                    </div>
                    <div className="flex justify-between items-center text-stone-300 mt-1">
                      <span>Unit Volume:</span>
                      <span className="font-bold text-white">{reg.units.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-center text-stone-300">
                      <span>Profit Margin %:</span>
                      <span className="font-bold text-[#c5a059]">{margin.toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between items-center text-stone-300">
                      <span>Net Profit:</span>
                      <span className="font-bold text-stone-100">${reg.profit.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
