/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ElementType } from "react";
import { motion } from "motion/react";

interface KpiCardProps {
  id: string;
  title: string;
  value: string | number;
  subtitle?: string;
  icon: ElementType;
  colorClass: string;
  trend?: {
    value: string;
    isPositive: boolean;
  };
}

export default function KpiCard({
  id,
  title,
  value,
  subtitle,
  icon: Icon,
  colorClass,
  trend
}: KpiCardProps) {
  return (
    <motion.div
      id={id}
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.025, y: -5, transition: { duration: 0.2, ease: "easeOut" } }}
      transition={{ duration: 0.3 }}
      className="bg-[#0c0c0c] border border-[#1a1a1a] rounded-xl p-5 flex flex-col justify-between transition-all hover:border-[#c5a059aa] shadow-lg hover:shadow-2xl hover:shadow-[#c5a05908] group cursor-pointer"
    >
      <div className="flex items-center justify-between">
        <span className="text-sm font-serif italic text-[#888] group-hover:text-white transition-colors">{title}</span>
        <div className="p-2 rounded-lg bg-[#111] border border-[#1a1a1a] text-[#c5a059] group-hover:bg-[#1a1a1a] transition-all">
          <Icon className="w-4 h-4" />
        </div>
      </div>

      <div className="mt-4">
        <h3 className="text-2xl font-serif text-white tracking-tight">
          {value}
        </h3>
        {subtitle && (
          <p className="text-[10px] text-[#555] uppercase tracking-widest font-mono mt-1">
            {subtitle}
          </p>
        )}
      </div>

      {trend && (
        <div className="mt-4 pt-3 border-t border-[#1a1a1a] flex items-center justify-between">
          <span className="text-[10px] uppercase tracking-wider text-[#444]">vs pre-sets</span>
          <span
            className={`text-[10px] uppercase tracking-wide font-medium px-2 py-0.5 rounded border ${
              trend.isPositive
                ? "bg-[#c5a05911] text-[#c5a059] border-[#c5a05922]"
                : "bg-[#111] text-[#666] border-[#222]"
            }`}
          >
            {trend.value}
          </span>
        </div>
      )}
    </motion.div>
  );
}
