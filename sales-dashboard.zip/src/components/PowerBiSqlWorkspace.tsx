/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from "react";
import { 
  Database, 
  Play, 
  HelpCircle, 
  AlertCircle, 
  CheckCircle2, 
  BarChart3, 
  LineChart, 
  PieChart, 
  TableProperties, 
  Sparkles, 
  Download, 
  RefreshCcw, 
  Code,
  Copy,
  ChevronRight,
  TrendingUp,
  Sliders,
  DollarSign,
  HeartIcon
} from "lucide-react";
import alasql from "alasql";
import { Transaction } from "../types";

interface PowerBiSqlWorkspaceProps {
  transactions: Transaction[];
}

interface QueryResult {
  columns: string[];
  rows: any[];
  latency: number;
}

export default function PowerBiSqlWorkspace({ transactions }: PowerBiSqlWorkspaceProps) {
  // SQL console states
  const [activeTab, setActiveTab] = useState<"query" | "visuals">("query");
  const [sqlQuery, setSqlQuery] = useState<string>(
    `SELECT \n  category,\n  ROUND(SUM(revenue), 2) AS total_revenue,\n  ROUND(SUM(profit), 2) AS total_profit,\n  ROUND((SUM(profit)/SUM(revenue)) * 100, 1) AS margin_percentage\nFROM ? \nGROUP BY category\nORDER BY total_revenue DESC`
  );
  
  const [queryResult, setQueryResult] = useState<QueryResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [executionStats, setExecutionStats] = useState<{ latency: number; count: number } | null>(null);
  const [copiedQuery, setCopiedQuery] = useState(false);

  // Power BI visual config states
  const [visualType, setVisualType] = useState<"bar" | "line" | "donut" | "kpi">("bar");
  const [selectedLabelCol, setSelectedLabelCol] = useState<string>("");
  const [selectedValueCol, setSelectedValueCol] = useState<string>("");
  const [selectedColorAccent, setSelectedColorAccent] = useState<string>("#c5a059");

  // Schema explorer properties
  const schemaFields = [
    { name: "id", type: "string (VARCHAR)", desc: "Invoice UUID identifier", sample: "INV-9402" },
    { name: "date", type: "string (DATE)", desc: "Chronological Timestamp (YYYY-MM-DD)", sample: "2026-04-18" },
    { name: "product", type: "string (VARCHAR)", desc: "Product catalog title", sample: "Ultra HD Monitor" },
    { name: "category", type: "string (VARCHAR)", desc: "Market classification", sample: "Electronics" },
    { name: "quantity", type: "number (INT)", desc: "Units sold counts", sample: "4" },
    { name: "price", type: "number (DECIMAL)", desc: "Sells price per individual unit", sample: "120.00" },
    { name: "cost", type: "number (DECIMAL)", desc: "Purchase cost per unit", sample: "75.00" },
    { name: "revenue", type: "number (DECIMAL)", desc: "Calculated gross revenue (quantity * price)", sample: "480.00" },
    { name: "profit", type: "number (DECIMAL)", desc: "Captured operational net profit (revenue - cost)", sample: "180.00" },
    { name: "region", type: "string (VARCHAR)", desc: "Geographical sales territory", sample: "North America" },
    { name: "channel", type: "string (VARCHAR)", desc: "Sales generation channel mode", sample: "Retail Direct" },
    { name: "paymentMethod", type: "string (VARCHAR)", desc: "Settlement transaction mode", sample: "Bank Transfer" }
  ];

  // Preset SQL Templates for Power BI Dashboards
  const PRESET_QUERIES = [
    {
      label: "Category Revenue Contribution",
      query: `SELECT \n  category,\n  COUNT(*) AS orders_count,\n  SUM(quantity) AS total_units_sold,\n  ROUND(SUM(revenue), 2) AS total_revenue,\n  ROUND(SUM(profit), 2) AS total_profit\nFROM ?\nGROUP BY category\nORDER BY total_revenue DESC`,
      visualType: "donut",
      labelCol: "category",
      valueCol: "total_revenue"
    },
    {
      label: "Monthly Historical Trends",
      query: `SELECT \n  SUBSTR(date, 1, 7) AS transaction_month,\n  ROUND(SUM(revenue), 2) AS monthly_revenue,\n  ROUND(SUM(profit), 2) AS monthly_profit\nFROM ?\nGROUP BY SUBSTR(date, 1, 7)\nORDER BY transaction_month ASC`,
      visualType: "line",
      labelCol: "transaction_month",
      valueCol: "monthly_revenue"
    },
    {
      label: "Regional Performance Breakdown",
      query: `SELECT \n  region,\n  ROUND(SUM(revenue), 2) AS regional_revenue,\n  SUM(quantity) AS aggregated_units\nFROM ?\nGROUP BY region\nORDER BY regional_revenue DESC`,
      visualType: "bar",
      labelCol: "region",
      valueCol: "regional_revenue"
    },
    {
      label: "Sells Channels Margin Efficiency",
      query: `SELECT \n  channel,\n  ROUND(SUM(revenue), 2) AS sales_revenue,\n  ROUND(SUM(profit), 2) AS sales_profit,\n  ROUND((SUM(profit) / SUM(revenue)) * 100, 1) AS profitability_rate\nFROM ?\nGROUP BY channel\nORDER BY profitability_rate DESC`,
      visualType: "bar",
      labelCol: "channel",
      valueCol: "profitability_rate"
    },
    {
      label: "Top 5 Cash Cows (High Value)",
      query: `SELECT \n  product,\n  category,\n  SUM(quantity) AS total_units_sold,\n  ROUND(SUM(revenue), 2) AS accumulated_revenue,\n  ROUND(SUM(profit), 2) AS accumulated_profit\nFROM ?\nGROUP BY product, category\nORDER BY accumulated_profit DESC\nLIMIT 5`,
      visualType: "bar",
      labelCol: "product",
      valueCol: "accumulated_profit"
    },
    {
      label: "Average Margin Profile Explorer",
      query: `SELECT \n  product,\n  ROUND(AVG(price), 2) AS average_price,\n  ROUND(AVG(cost), 2) AS average_cost,\n  ROUND(((AVG(price) - AVG(cost)) / AVG(price)) * 100, 1) AS average_margin\nFROM ?\nGROUP BY product\nHAVING average_price > 50\nORDER BY average_margin DESC`,
      visualType: "bar",
      labelCol: "product",
      valueCol: "average_margin"
    }
  ];

  // Run the current SQL input against current transactions
  const executeQuery = (queryText: string = sqlQuery) => {
    setErrorMsg(null);
    const start = performance.now();
    try {
      // alaSQL uses a placeholder '?' for array datasets
      const result = alasql(queryText, [transactions]);
      const end = performance.now();
      const latencyMs = parseFloat((end - start).toFixed(2));

      if (result && Array.isArray(result) && result.length > 0) {
        // Collect exact keys
        const columns = Object.keys(result[0]);
        setQueryResult({
          columns,
          rows: result,
          latency: latencyMs
        });
        setExecutionStats({
          latency: latencyMs,
          count: result.length
        });

        // Set default visual labels and values if empty or invalid
        if (columns.length > 0) {
          // Find first string column
          const labelCol = columns.find(col => {
            const val = result[0][col];
            return typeof val === "string";
          }) || columns[0];

          // Find first numerical column (excluding ID/dates keys if possible)
          const valCol = columns.find(col => {
            const val = result[0][col];
            return typeof val === "number" && col !== "id";
          }) || columns[1] || columns[0];

          setSelectedLabelCol(labelCol);
          setSelectedValueCol(valCol);
        }
      } else if (result && Array.isArray(result)) {
        // Empty result set
        setQueryResult({
          columns: [],
          rows: [],
          latency: latencyMs
        });
        setExecutionStats({
          latency: latencyMs,
          count: 0
        });
      } else {
        throw new Error("Query did not return a valid tabular collection.");
      }
    } catch (err: any) {
      console.error("alaSQL query execution fault:", err);
      setErrorMsg(err.message || "Unknown syntax database error occurred.");
      setQueryResult(null);
      setExecutionStats(null);
    }
  };

  // Run initial query on mount or when transactions length changes
  useEffect(() => {
    executeQuery();
  }, [transactions.length]);

  // Handle template selection
  const selectQueryTemplate = (item: typeof PRESET_QUERIES[0]) => {
    setSqlQuery(item.query);
    setActiveTab("query");
    
    // Auto-setup visuals
    setVisualType(item.visualType as any);
    
    // Delay slightly to let transactions parse before mapping columns
    setTimeout(() => {
      executeQuery(item.query);
      if (item.labelCol) setSelectedLabelCol(item.labelCol);
      if (item.valueCol) setSelectedValueCol(item.valueCol);
    }, 50);
  };

  // Copy sql code helper
  const copyQueryToClipboard = () => {
    navigator.clipboard.writeText(sqlQuery);
    setCopiedQuery(true);
    setTimeout(() => setCopiedQuery(false), 2000);
  };

  // Export results CSV helper
  const exportCsvResult = () => {
    if (!queryResult || queryResult.rows.length === 0) return;
    
    const headers = queryResult.columns.join(",");
    const csvRows = queryResult.rows.map(row => 
      queryResult.columns.map(col => {
        const val = row[col];
        // wrap strings with commas in quotes
        if (typeof val === "string" && val.includes(",")) {
          return `"${val}"`;
        }
        return val !== null && val !== undefined ? val : "";
      }).join(",")
    );
    
    const fullCsv = [headers, ...csvRows].join("\n");
    const blob = new Blob([fullCsv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `sql_query_export_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Keyboard shortcut Ctrl+Enter / Cmd+Enter inside code terminal
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
      e.preventDefault();
      executeQuery();
    }
  };

  // Dynamic visual render values
  const visualChartData = useMemo(() => {
    if (!queryResult || !selectedLabelCol || !selectedValueCol) return [];
    
    return queryResult.rows.map(row => {
      const rawLabel = row[selectedLabelCol];
      const rawVal = row[selectedValueCol];
      
      return {
        label: rawLabel !== undefined && rawLabel !== null ? String(rawLabel) : "N/A",
        value: typeof rawVal === "number" ? rawVal : parseFloat(String(rawVal)) || 0,
        rawRow: row
      };
    });
  }, [queryResult, selectedLabelCol, selectedValueCol]);

  // Aggregate sums for visuals
  const visualAggregateSummary = useMemo(() => {
    if (visualChartData.length === 0) return { total: 0, avg: 0, min: 0, max: 0 };
    const values = visualChartData.map(d => d.value);
    const total = values.reduce((sum, v) => sum + v, 0);
    const avg = total / values.length;
    return {
      total: parseFloat(total.toFixed(2)),
      avg: parseFloat(avg.toFixed(2)),
      min: parseFloat(Math.min(...values).toFixed(2)),
      max: parseFloat(Math.max(...values).toFixed(2))
    };
  }, [visualChartData]);

  return (
    <div className="bg-[#0b0b0b] border border-[#161616] rounded-xl overflow-hidden shadow-xl" id="power-bi-live-sql-panel">
      {/* Power BI Header block */}
      <div className="p-5 border-b border-[#161616] bg-[#070707] flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-[#c5a059] text-[#111] text-[10px] uppercase font-mono font-bold px-2 py-0.5 rounded">
              Power BI Engine
            </span>
            <div className="flex items-center gap-1.5 text-white">
              <Database className="w-4 h-4 text-[#c5a059]" />
              <h3 className="text-md font-serif italic tracking-tight">Active SQL-Live Sandbox Workspace</h3>
            </div>
          </div>
          <p className="text-xs text-[#888] mt-1.5 leading-relaxed">
            Run standard structural SQL queries over your live transactions register using <code className="text-[#c5a059] font-mono">alasql</code>. 
            Build real-time visuals and model reports immediately on custom criteria.
          </p>
        </div>

        {/* View Mode Custom tab switcher */}
        <div className="flex rounded-lg bg-[#111] p-1 border border-[#1e1e1e]">
          <button
            onClick={() => setActiveTab("query")}
            className={`px-3 py-1.5 rounded-md text-xs font-mono flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === "query" 
                ? "bg-[#c5a059] text-black font-semibold" 
                : "text-[#888] hover:text-white"
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            SQL Worksheet
          </button>
          <button
            onClick={() => setActiveTab("visuals")}
            className={`px-3 py-1.5 rounded-md text-xs font-mono flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === "visuals" 
                ? "bg-[#c5a059] text-black font-semibold" 
                : "text-[#888] hover:text-white"
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Power BI Visuals ({visualChartData.length})
          </button>
        </div>
      </div>

      {/* Main split working canvas */}
      <div className="grid grid-cols-1 xl:grid-cols-4 divide-y xl:divide-y-0 xl:divide-x divide-[#161616]">
        
        {/* LEFT COLUMN: SQL Quick Templates & Schema Map Dictionary */}
        <div className="xl:col-span-1 p-5 bg-[#080808] flex flex-col gap-6 max-h-[640px] overflow-y-auto custom-scrollbar">
          
          {/* Section A: Schema Helper */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Sliders className="w-3.5 h-3.5 text-[#c5a059]" />
              <span className="text-xs font-mono uppercase tracking-wider text-white">Schema Metadata</span>
            </div>
            
            <div className="text-[11px] bg-[#0c0c0c] border border-[#1a1a1a] rounded-lg p-2.5 flex flex-col gap-2">
              <div className="font-mono text-[#c5a059] font-semibold flex items-center justify-between border-b border-[#222] pb-1.5">
                <span>TABLE: transactions</span>
                <span className="text-[9px] text-[#555] font-normal">{transactions.length} active rows</span>
              </div>
              <div className="divide-y divide-[#1e1e1e] max-h-[160px] overflow-y-auto pr-1">
                {schemaFields.map(f => (
                  <div key={f.name} className="py-1.5 flex flex-col gap-0.5 group">
                    <div className="flex items-center justify-between font-mono">
                      <span 
                        onClick={() => {
                          // Insert field into text area helper
                          const textarea = document.getElementById("sql-terminal-textarea") as HTMLTextAreaElement;
                          if (textarea) {
                            const start = textarea.selectionStart;
                            const end = textarea.selectionEnd;
                            const text = textarea.value;
                            const newText = text.substring(0, start) + f.name + text.substring(end);
                            setSqlQuery(newText);
                            textarea.focus();
                          }
                        }}
                        className="text-stone-300 font-bold hover:text-[#c5a059] cursor-pointer transition-colors"
                        title="Click to insert field"
                      >
                        {f.name}
                      </span>
                      <span className="text-[9px] text-[#555] italic">{f.type}</span>
                    </div>
                    <p className="text-[10px] text-[#888]">{f.desc}</p>
                    <div className="text-[9px] font-mono text-[#444] group-hover:text-[#666] transition-colors mt-0.5">
                      sample: {f.sample}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Section B: Preset Templates list */}
          <div>
            <div className="flex items-center gap-2 mb-2.5">
              <Sparkles className="w-3.5 h-3.5 text-[#c5a059]" />
              <span className="text-xs font-mono uppercase tracking-wider text-white">Report Templates</span>
            </div>
            
            <div className="flex flex-col gap-2">
              {PRESET_QUERIES.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => selectQueryTemplate(item)}
                  className="w-full text-left p-2.5 hover:p-3 rounded-lg bg-[#0d0d0d] border border-[#1c1c1c] hover:border-[#c5a05944] text-[11px] text-[#aaa] hover:text-white transition-all flex flex-col gap-1 items-start group cursor-pointer hover:bg-[#121212]"
                >
                  <span className="font-serif italic text-white group-hover:text-[#c5a059] flex items-center gap-1 transition-colors">
                    <ChevronRight className="w-3 h-3 text-[#c5a059]" />
                    {item.label}
                  </span>
                  <code className="text-[9px] font-mono text-[#555] group-hover:text-[#aaa] truncate w-full block">
                    {item.query.substring(0, 70)}...
                  </code>
                </button>
              ))}
            </div>
          </div>
          
        </div>

        {/* RIGHT COLUMN: Interactive Work-area (Queries and Data Tables/Visual charts) */}
        <div className="xl:col-span-3 p-5 flex flex-col gap-5 bg-[#050505]">
          
          {activeTab === "query" ? (
            /* ====================================
               TAB 1: WORKSPACE QUERY CONSOLE & GRID
               ==================================== */
            <div className="flex flex-col gap-5">
              
              {/* Code Terminal Box */}
              <div className="relative border border-[#1b1b1b] rounded-lg bg-[#080808] overflow-hidden">
                <div className="p-2 px-4 border-b border-[#1b1b1b] bg-[#0c0c0c] flex items-center justify-between text-[11px] font-mono font-medium">
                  <div className="flex items-center gap-2 text-[#aaa]">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#ef4444]"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-[#f59e0b]"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-[#10b981]"></span>
                    <span className="text-[#888] ml-2">sales_revenue_queries.sql</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={copyQueryToClipboard}
                      className="text-[#666] hover:text-white flex items-center gap-1 text-[10px] transition-colors cursor-pointer"
                    >
                      <Copy className="w-3 h-3 text-[#c5a059]" />
                      {copiedQuery ? "Copied!" : "Copy SQL"}
                    </button>
                    <span className="text-[#444]">|</span>
                    <span className="text-[#555] text-[10px]">Press Ctrl+Enter to execute</span>
                  </div>
                </div>

                {/* SQL Editor Area */}
                <div className="relative">
                  <textarea
                    id="sql-terminal-textarea"
                    value={sqlQuery}
                    onChange={(e) => setSqlQuery(e.target.value)}
                    onKeyDown={handleKeyDown}
                    rows={6}
                    className="w-full bg-[#080808] text-white font-mono text-xs p-4 leading-relaxed outline-none border-none resize-y focus:ring-1 focus:ring-[#c5a05955] selection:bg-[#c5a05922]"
                    placeholder="-- Type your custom Live SQL Query here..."
                  />
                </div>

                {/* Execution Bar buttons */}
                <div className="p-3 bg-[#0a0a0a] border-t border-[#1b1b1b] flex items-center justify-between">
                  <div className="flex items-center gap-2.5 text-xs">
                    {errorMsg ? (
                      <div className="flex items-center gap-1.5 text-red-400 font-mono">
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>Query failed. Review console error below.</span>
                      </div>
                    ) : executionStats ? (
                      <div className="flex items-center gap-1.5 text-emerald-400 font-mono">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Returned {executionStats.count} records in {executionStats.latency}ms</span>
                      </div>
                    ) : (
                      <span className="text-[#555] font-mono">Status: Ready</span>
                    )}
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setSqlQuery(`SELECT * FROM ? LIMIT 50`)}
                      className="px-3 py-1.5 rounded text-[11px] font-mono tracking-wider uppercase border border-[#222] hover:border-[#444] text-[#888] hover:text-white transition-all cursor-pointer"
                    >
                      Reset Query
                    </button>
                    <button
                      onClick={() => executeQuery()}
                      className="px-5 py-1.5 rounded bg-[#c5a059] text-black hover:bg-[#b08c48] font-mono font-bold tracking-wider uppercase text-[11px] flex items-center gap-1.5 shadow-lg active:scale-95 transition-all cursor-pointer"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      Run Statement
                    </button>
                  </div>
                </div>
              </div>

              {/* Warnings / Error feedback blocks */}
              {errorMsg && (
                <div className="p-4 bg-red-950/15 border-l-4 border-red-500 rounded-lg text-xs leading-relaxed text-red-200 font-mono flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-red-400">SQL Error:</strong> {errorMsg}
                    <div className="mt-2 text-[#aaa] leading-relaxed text-[11px]">
                      Tip: Ensure your target source table matches our placeholder parameter: <code className="bg-[#220000] text-red-300 font-bold px-1.5 py-0.5 rounded border border-red-950">?</code>. For example: <br />
                      <code className="text-stone-300 font-mono text-[10px]">SELECT category, SUM(revenue) FROM ? GROUP BY category</code>
                    </div>
                  </div>
                </div>
              )}

              {/* Query Result Grid Table */}
              {queryResult ? (
                <div className="border border-[#141414] rounded-lg overflow-hidden bg-[#0c0c0c]">
                  <div className="p-3 bg-[#080808] border-b border-[#141414] flex items-center justify-between px-4">
                    <span className="text-xs text-[#aaa] font-bold font-serif italic">
                      Query Out-Matrix Console View
                    </span>
                    {queryResult.rows.length > 0 && (
                      <button
                        onClick={exportCsvResult}
                        className="text-[10px] text-[#c5a059] hover:text-white font-mono flex items-center gap-1.5 tracking-wider uppercase transition-colors cursor-pointer"
                      >
                        <Download className="w-3 h-3" />
                        Export SQL CSV
                      </button>
                    )}
                  </div>

                  {queryResult.rows.length === 0 ? (
                    <div className="p-8 text-center text-[#555] font-mono text-xs">
                      No matching tuples returned. Query executed perfectly or return set was empty.
                    </div>
                  ) : (
                    <div className="overflow-x-auto max-h-[300px] custom-scrollbar">
                      <table className="w-full text-left font-mono text-[11px] text-stone-300 border-collapse">
                        <thead>
                          <tr className="bg-[#050505] border-b border-[#1c1c1c] divide-x divide-[#151515] text-[#888]">
                            {queryResult.columns.map(col => (
                              <th key={col} className="p-2.5 font-bold tracking-wide uppercase hover:text-white transition-colors">
                                {col}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#121212]">
                          {queryResult.rows.map((row, idx) => (
                            <tr 
                              key={idx} 
                              className="hover:bg-[#111] border-b border-[#121212] divide-x divide-[#121212] transition-colors"
                            >
                              {queryResult.columns.map(col => {
                                const val = row[col];
                                return (
                                  <td key={col} className="p-2">
                                    {val === null || val === undefined ? (
                                      <span className="text-[#333] italic">NULL</span>
                                    ) : typeof val === "number" ? (
                                      <span className="text-stone-100 font-semibold text-right block pr-1">
                                        {val.toLocaleString(undefined, { maximumFractionDigits: 3 })}
                                      </span>
                                    ) : (
                                      <span>{String(val)}</span>
                                    )}
                                  </td>
                                );
                              })}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-12 border-2 border-dashed border-[#181818] rounded-xl text-center text-[#444] font-mono text-xs flex flex-col items-center justify-center gap-2">
                  <TableProperties className="w-8 h-8 text-[#222]" />
                  <span>Execute a valid query statement to populate matrix console.</span>
                </div>
              )}
              
            </div>
          ) : (
            /* ==========================================
               TAB 2: POWER BI EXQUISITE REPORT VISUAL CANVAS
               ========================================== */
            <div className="flex flex-col gap-5">
              
              {/* Visual customizer controls row */}
              <div className="p-4 bg-[#080808] border border-[#161616] rounded-lg grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                
                {/* Selector 1: Chart type */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-[#888] uppercase tracking-wider">Visual Type</label>
                  <div className="grid grid-cols-4 gap-1.5">
                    <button
                      onClick={() => setVisualType("bar")}
                      className={`p-1.5 rounded transition-all cursor-pointer flex items-center justify-center ${
                        visualType === "bar" ? "bg-[#c5a059] text-black" : "bg-[#121212] text-[#888] hover:text-white"
                      }`}
                      title="Bar Plot Chart"
                    >
                      <BarChart3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setVisualType("line")}
                      className={`p-1.5 rounded transition-all cursor-pointer flex items-center justify-center ${
                        visualType === "line" ? "bg-[#c5a059] text-black" : "bg-[#121212] text-[#888] hover:text-white"
                      }`}
                      title="Trend Area Line"
                    >
                      <LineChart className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setVisualType("donut")}
                      className={`p-1.5 rounded transition-all cursor-pointer flex items-center justify-center ${
                        visualType === "donut" ? "bg-[#c5a059] text-black" : "bg-[#121212] text-[#888] hover:text-white"
                      }`}
                      title="Share Donut Chart"
                    >
                      <PieChart className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setVisualType("kpi")}
                      className={`p-1.5 rounded transition-all cursor-pointer flex items-center justify-center ${
                        visualType === "kpi" ? "bg-[#c5a059] text-black" : "bg-[#121212] text-[#888] hover:text-white"
                      }`}
                      title="Big Summary Metrics Tile"
                    >
                      <TrendingUp className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Selector 2: X-axis Label Column */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-[#888] uppercase tracking-wider">Axis Label (X / Item)</label>
                  <select
                    value={selectedLabelCol}
                    onChange={(e) => setSelectedLabelCol(e.target.value)}
                    className="bg-[#121212] border border-[#222] text-[#ccc] rounded p-1.5 px-3 text-xs outline-none focus:border-[#c5a05955]"
                  >
                    {queryResult?.columns.map(col => (
                      <option key={col} value={col}>{col}</option>
                    )) || <option value="">No active query columns</option>}
                  </select>
                </div>

                {/* Selector 3: Y-axis Value Column */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-[#888] uppercase tracking-wider">Axis Value (Y / Numeric)</label>
                  <select
                    value={selectedValueCol}
                    onChange={(e) => setSelectedValueCol(e.target.value)}
                    className="bg-[#121212] border border-[#222] text-[#ccc] rounded p-1.5 px-3 text-xs outline-none focus:border-[#c5a05955]"
                  >
                    {queryResult?.columns.map(col => (
                      <option key={col} value={col}>{col}</option>
                    )) || <option value="">No active query columns</option>}
                  </select>
                </div>

                {/* Selector 4: Palette theme */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-mono text-[#888] uppercase tracking-wider">Color Theme Accent</label>
                  <div className="flex items-center gap-2">
                    {["#c5a059", "#111111", "#a68444", "#3b82f6", "#10b981"].map(color => (
                      <button
                        key={color}
                        onClick={() => setSelectedColorAccent(color)}
                        style={{ backgroundColor: color === "#111111" ? "#ffffff" : color }}
                        className={`w-4 h-4 rounded-full border transition-transform cursor-pointer ${
                          selectedColorAccent === color ? "scale-125 border-white ring-1 ring-white" : "border-transparent opacity-60 hover:opacity-100"
                        }`}
                        title={color}
                      />
                    ))}
                    <span className="text-[10px] font-mono text-stone-500 truncate lowercase">{selectedColorAccent}</span>
                  </div>
                </div>

              </div>

              {/* Dynamic canvas presentation */}
              {visualChartData.length === 0 ? (
                <div className="p-16 border-2 border-dashed border-[#1a1a1a] rounded-xl text-center text-[#555] font-mono text-xs flex flex-col items-center justify-center gap-2">
                  <Sliders className="w-8 h-8 text-[#222]" />
                  <span>Execute a valid query in the SQL Worksheet tab first and return sets to visualize.</span>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                  
                  {/* MAIN CHART WINDOW: Visual panel */}
                  <div className="lg:col-span-2 bg-[#0a0a0a] border border-[#141414] rounded-xl p-5 flex flex-col justify-between min-h-[350px]">
                    <div>
                      <div className="flex items-center justify-between border-b border-[#1c1c1c] pb-3 mb-4">
                        <div className="flex items-center gap-2">
                          <BarChart3 className="w-4 h-4 text-[#c5a059]" />
                          <h4 className="text-xs font-mono uppercase tracking-wider text-white">
                            Power BI Interactive Model Visual Layout
                          </h4>
                        </div>
                        <div className="text-[10px] font-mono text-stone-500">
                          PROJECTION FIELD: <code className="text-[#c5a059]">{selectedValueCol}</code> BY <code className="text-[#c5a059]">{selectedLabelCol}</code>
                        </div>
                      </div>

                      {/* Display calculations for scaling */}
                      {(() => {
                        const maxVal = Math.max(...visualChartData.map(d => d.value), 1);
                        const minVal = Math.min(...visualChartData.map(d => d.value), 0);
                        const dataLen = visualChartData.length;

                        if (visualType === "bar") {
                          /* ====================
                             VISUAL A: BAR PLOTS
                             ==================== */
                          return (
                            <div className="flex flex-col gap-3 py-2">
                              {visualChartData.slice(0, 8).map((data, idx) => {
                                const percent = Math.max(2, Math.round((data.value / maxVal) * 100));
                                return (
                                  <div key={idx} className="flex items-center gap-3 group text-xs">
                                    <div className="w-24 text-stone-400 font-mono text-[10px] truncate" title={data.label}>
                                      {data.label}
                                    </div>
                                    <div className="flex-1 bg-[#121212] rounded h-5 overflow-hidden border border-[#1e1e1e] flex items-center relative">
                                      <div
                                        style={{ 
                                          width: `${percent}%`,
                                          backgroundColor: selectedColorAccent === "#111111" ? "#ffffff" : selectedColorAccent
                                        }}
                                        className="h-full rounded-r transition-all duration-500 absolute left-0 top-0 opacity-80 group-hover:opacity-100"
                                      />
                                      <div className="absolute right-2 text-[9px] font-mono text-stone-400 group-hover:text-white font-bold transition-all">
                                        {data.value.toLocaleString(undefined, { maximumFractionDigits: 1 })}
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                              {dataLen > 8 && (
                                <div className="text-[9px] text-[#555] font-mono text-right italic pt-1">
                                  + {dataLen - 8} additional rows hidden in visual summary. View SQL Worksheet for full data.
                                </div>
                              )}
                            </div>
                          );
                        } else if (visualType === "line") {
                          /* =====================
                             VISUAL B: LINE SHAPES
                             ===================== */
                          const svgW = 500;
                          const svgH = 180;
                          const padX = 50;
                          const padY = 20;
                          const chartW = svgW - padX * 2;
                          const chartH = svgH - padY * 2;
                          
                          // generate line path coordinates
                          const points = visualChartData
                            .map((d, index) => {
                              const x = padX + (index / Math.max(dataLen - 1, 1)) * chartW;
                              const y = padY + chartH - ((d.value - minVal) / Math.max(maxVal - minVal, 1)) * chartH;
                              return `${x},${y}`;
                            })
                            .join(" ");

                          const areaPoints = points
                            ? `${padX},${padY + chartH} ${points} ${padX + chartW},${padY + chartH}`
                            : "";

                          return (
                            <div className="relative w-full flex items-center justify-center p-2">
                              <svg viewBox={`0 0 ${svgW} ${svgH}`} className="w-full h-auto text-stone-400">
                                {/* Grid reference lines */}
                                <line x1={padX} y1={padY} x2={padX + chartW} y2={padY} stroke="#1b1b1b" strokeDasharray="3,3" />
                                <line x1={padX} y1={padY + chartH/2} x2={padX + chartW} y2={padY + chartH/2} stroke="#1b1b1b" strokeDasharray="3,3" />
                                <line x1={padX} y1={padY + chartH} x2={padX + chartW} y2={padY + chartH} stroke="#222" strokeWidth="1.5" />
                                
                                {/* Fill Area below line */}
                                {areaPoints && (
                                  <polygon 
                                    points={areaPoints}
                                    fill={selectedColorAccent === "#111111" ? "#ffffff" : selectedColorAccent}
                                    fillOpacity="0.06"
                                  />
                                )}

                                {/* Main Line vector path */}
                                {points && (
                                  <polyline
                                    fill="none"
                                    stroke={selectedColorAccent === "#111111" ? "#ffffff" : selectedColorAccent}
                                    strokeWidth="2.5"
                                    points={points}
                                    className="transition-all"
                                  />
                                )}

                                {/* Anchor Dot coordinates */}
                                {visualChartData.map((d, index) => {
                                  const x = padX + (index / Math.max(dataLen - 1, 1)) * chartW;
                                  const y = padY + chartH - ((d.value - minVal) / Math.max(maxVal - minVal, 1)) * chartH;
                                  return (
                                    <g key={index} className="group/dot cursor-pointer">
                                      <circle
                                        cx={x}
                                        cy={y}
                                        r="3.5"
                                        fill="#050505"
                                        stroke={selectedColorAccent === "#111111" ? "#ffffff" : selectedColorAccent}
                                        strokeWidth="2"
                                      />
                                      <circle
                                        cx={x}
                                        cy={y}
                                        r="7"
                                        fill={selectedColorAccent === "#111111" ? "#ffffff" : selectedColorAccent}
                                        fillOpacity="0.3"
                                        className="opacity-0 group-hover/dot:opacity-100 transition-opacity"
                                      />
                                      <text
                                        x={x}
                                        y={y - 8}
                                        className="text-[8px] font-mono fill-white opacity-0 group-hover/dot:opacity-100 text-center font-bold"
                                        textAnchor="middle"
                                      >
                                        {d.value.toFixed(0)}
                                      </text>
                                    </g>
                                  );
                                })}

                                {/* Labels values bottom */}
                                <text x={padX} y={svgH - 4} className="text-[8px] font-mono fill-stone-500" textAnchor="middle">
                                  {visualChartData[0]?.label}
                                </text>
                                <text x={padX + chartW} y={svgH - 4} className="text-[8px] font-mono fill-stone-500" textAnchor="middle">
                                  {visualChartData[dataLen - 1]?.label}
                                </text>
                              </svg>
                            </div>
                          );
                        } else if (visualType === "donut") {
                          /* =========================
                             VISUAL C: PIE/DONUT SHARE
                             ========================= */
                          const totalSum = visualChartData.reduce((s, item) => s + item.value, 0) || 1;
                          
                          return (
                            <div className="flex flex-col md:flex-row items-center justify-around gap-6 py-2">
                              {/* Left details indicators list */}
                              <div className="flex flex-col gap-2 max-w-[200px] w-full">
                                {visualChartData.slice(0, 6).map((data, idx) => {
                                  const share = (data.value / totalSum) * 100;
                                  return (
                                    <div key={idx} className="flex items-center justify-between text-[10px] font-mono">
                                      <div className="flex items-center gap-1.5 truncate">
                                        <span 
                                          style={{ 
                                            backgroundColor: selectedColorAccent === "#111111" ? "#ffffff" : selectedColorAccent,
                                            opacity: 1 - idx * 0.14
                                          }} 
                                          className="w-2 h-2 rounded-sm shrink-0" 
                                        />
                                        <span className="text-stone-300 truncate font-serif italic">{data.label}</span>
                                      </div>
                                      <span className="text-stone-500 font-bold">{share.toFixed(1)}%</span>
                                    </div>
                                  );
                                })}
                              </div>

                              {/* Right dynamic concentric ring representation */}
                              <div className="relative w-36 h-36 flex items-center justify-center">
                                <svg width="100%" height="100%" viewBox="0 0 42 42" className="transform -rotate-90">
                                  <circle cx="21" cy="21" r="15.915" fill="transparent" stroke="#111" strokeWidth="2.5" />
                                  {(() => {
                                    let accumulatedPercent = 0;
                                    return visualChartData.slice(0, 5).map((data, idx) => {
                                      const pct = (data.value / totalSum) * 100;
                                      const strokeDasharray = `${pct} ${100 - pct}`;
                                      const strokeDashoffset = 100 - accumulatedPercent + 25; // standard base offset
                                      accumulatedPercent += pct;

                                      return (
                                        <circle
                                          key={idx}
                                          cx="21"
                                          cy="21"
                                          r="15.915"
                                          fill="transparent"
                                          stroke={selectedColorAccent === "#111111" ? "#ffffff" : selectedColorAccent}
                                          strokeWidth="3.5"
                                          strokeDasharray={strokeDasharray}
                                          strokeDashoffset={strokeDashoffset}
                                          strokeLinecap="round"
                                          opacity={1 - idx * 0.16}
                                          className="transition-all hover:stroke-white cursor-pointer"
                                        />
                                      );
                                    });
                                  })()}
                                </svg>
                                <div className="absolute flex flex-col items-center justify-center text-center">
                                  <span className="text-[9px] font-mono text-stone-500 uppercase tracking-widest">Share Weight</span>
                                  <span className="text-xs font-serif font-bold text-white italic">
                                    {(totalSum > 10000 ? `$${(totalSum/1000).toFixed(1)}k` : totalSum.toLocaleString())}
                                  </span>
                                </div>
                              </div>
                            </div>
                          );
                        } else {
                          /* ============================
                             VISUAL D: OVERALL KPI CARDS
                             ============================ */
                          return (
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-3">
                              <div className="bg-[#111111] p-4 rounded-lg border border-[#1e1e1e] flex flex-col justify-between">
                                <span className="text-[10px] font-mono text-stone-500 uppercase tracking-wider">
                                  Cumulative Metrics Aggregation ({selectedValueCol})
                                </span>
                                <h5 className="text-xl font-serif text-white font-bold italic mt-2">
                                  {visualAggregateSummary.total.toLocaleString()}
                                </h5>
                                <span className="text-[9px] font-mono text-stone-600 mt-1">
                                  Calculated over {dataLen} rows returned
                                </span>
                              </div>
                              <div className="bg-[#111111] p-4 rounded-lg border border-[#1e1e1e] flex flex-col justify-between">
                                <span className="text-[10px] font-mono text-stone-500 uppercase tracking-wider">
                                  Statistical Model Average Value
                                </span>
                                <h5 className="text-xl font-serif text-[#c5a059] font-bold italic mt-2">
                                  {visualAggregateSummary.avg.toLocaleString()}
                                </h5>
                                <span className="text-[9px] font-mono text-stone-600 mt-1">
                                  Standard arithmetic query mean
                                </span>
                              </div>
                            </div>
                          );
                        }
                      })()}

                    </div>
                    
                    <div className="border-t border-[#141414] pt-3 text-[10px] font-mono text-stone-500 flex justify-between items-center mt-4">
                      <span>Interactive Power BI canvas fully coupled to user queries.</span>
                      <span className="flex items-center gap-1">
                        Model integrity verified <Sliders className="w-3 h-3 text-[#c5a059]" />
                      </span>
                    </div>

                  </div>

                  {/* SIDEBAR ANALYTICS: Bento metadata KPIs */}
                  <div className="flex flex-col gap-4">
                    
                    {/* Aggregation card A */}
                    <div className="bg-[#0b0b0b] border border-[#161616] rounded-xl p-4 flex flex-col justify-between">
                      <div className="flex items-center justify-between text-[10px] font-mono text-stone-500 uppercase tracking-wider">
                        <span>Database Yield Sum</span>
                        <TrendingUp className="w-3.5 h-3.5 text-[#c5a059]" />
                      </div>
                      <div className="mt-3">
                        <span className="text-2xl font-serif text-white font-bold italic">
                          ${visualAggregateSummary.total.toLocaleString(undefined, { maximumFractionDigits: 1 })}
                        </span>
                        <p className="text-[10px] text-stone-500 mt-1 leading-relaxed">
                          Summation of numerical column <code className="text-white font-mono">{selectedValueCol}</code> within queried datasets.
                        </p>
                      </div>
                    </div>

                    {/* Aggregation card B */}
                    <div className="bg-[#0b0b0b] border border-[#161616] rounded-xl p-4 flex flex-col justify-between">
                      <div className="flex items-center justify-between text-[10px] font-mono text-stone-500 uppercase tracking-wider">
                        <span>Range Peak (Max)</span>
                        <Sliders className="w-3.5 h-3.5 text-stone-400" />
                      </div>
                      <div className="mt-3">
                        <span className="text-xl font-serif text-stone-200 font-bold italic">
                          {visualAggregateSummary.max.toLocaleString()}
                        </span>
                        <div className="flex justify-between text-[9px] font-mono text-stone-500 mt-1.5 border-t border-[#1a1a1a] pt-1">
                          <span>Minimum Record:</span>
                          <span className="text-stone-300 font-bold">{visualAggregateSummary.min.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    {/* Interactive prompt help */}
                    <div className="bg-[#0c0c0c] border border-[#191919] p-4 rounded-xl text-[10.5px] leading-relaxed text-[#888]">
                      <span className="text-[#c5a059] font-mono font-bold block uppercase tracking-wider mb-1 text-[9.5px]">
                        💡 Power BI Visual Tips
                      </span>
                      Change the X and Y properties above or modify the query code in <strong className="text-white font-mono uppercase bg-[#181818] p-0.5 px-1 rounded text-[9px]">SQL Worksheet</strong> to custom design visual reports. You can graph category trends, payment profiles, or top product performances instantaneously.
                    </div>

                  </div>

                </div>
              )}

            </div>
          )}

        </div>

      </div>

    </div>
  );
}
