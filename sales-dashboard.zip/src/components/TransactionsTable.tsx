/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { Download, Upload, Plus, Trash2, ArrowUpDown, ChevronLeft, ChevronRight, FileSpreadsheet, Printer } from "lucide-react";
import { Transaction } from "../types";
import { CATEGORIES, REGIONS, CHANNELS, PAYMENT_METHODS } from "../data";

interface TransactionsTableProps {
  transactions: Transaction[];
  onAddTransaction: (t: Transaction) => void;
  onAddMultipleTransactions: (arr: Transaction[]) => void;
  onDeleteTransaction: (id: string) => void;
  onClearAll: () => void;
}

type SortField = "id" | "date" | "revenue" | "profit" | "quantity";
type SortOrder = "asc" | "desc";

export default function TransactionsTable({
  transactions,
  onAddTransaction,
  onAddMultipleTransactions,
  onDeleteTransaction,
  onClearAll
}: TransactionsTableProps) {
  // Page pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  // Sorting state
  const [sortField, setSortField] = useState<SortField>("date");
  const [sortOrder, setSortOrder] = useState<SortOrder>("desc");

  // Manual Add Form visible toggle and field state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const productInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleToggle = () => {
      setIsFormOpen((prev) => !prev);
    };
    window.addEventListener("toggle-add-sale-form", handleToggle);
    return () => {
      window.removeEventListener("toggle-add-sale-form", handleToggle);
    };
  }, []);

  useEffect(() => {
    if (isFormOpen) {
      // Small timeout to allow render completion
      const timer = setTimeout(() => {
        productInputRef.current?.focus();
        productInputRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      }, 80);
      return () => clearTimeout(timer);
    }
  }, [isFormOpen]);

  const [newRow, setNewRow] = useState({
    date: new Date().toISOString().split("T")[0],
    product: "",
    category: "Electronics",
    quantity: 1,
    price: 150.0,
    cost: 80.0,
    region: "North America",
    channel: "Online Store",
    paymentMethod: "Credit Card"
  });

  // Real-time derived validation & interactive calculations preview
  const parsedQty = parseInt(String(newRow.quantity), 10);
  const parsedPrice = parseFloat(String(newRow.price));
  const parsedCost = parseFloat(String(newRow.cost));

  const qtyError = isNaN(parsedQty) || parsedQty < 1 
    ? "Units sold must be a positive integer (minimum 1)." 
    : "";
  const priceError = isNaN(parsedPrice) || parsedPrice < 0 
    ? "Unit price cannot be negative." 
    : "";
  const costError = isNaN(parsedCost) || parsedCost < 0 
    ? "Unit cost cannot be negative." 
    : "";

  const displayQty = isNaN(parsedQty) || parsedQty < 1 ? 0 : parsedQty;
  const displayPrice = isNaN(parsedPrice) || parsedPrice < 0 ? 0 : parsedPrice;
  const displayCost = isNaN(parsedCost) || parsedCost < 0 ? 0 : parsedCost;

  const estimatedRev = displayQty * displayPrice;
  const estimatedCost = displayQty * displayCost;
  const estimatedProfitVal = estimatedRev - estimatedCost;
  const estimatedMarginVal = estimatedRev > 0 ? (estimatedProfitVal / estimatedRev) * 100 : 0;

  const qtyHasError = !!qtyError;
  const priceHasError = !!priceError;
  const costHasError = !!costError;
  const anyFormError = qtyHasError || priceHasError || costHasError;

  // CSV Drag and paste importer trigger states
  const [isImporterOpen, setIsImporterOpen] = useState(false);
  const [csvInput, setCsvInput] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importerError, setImporterError] = useState("");

  // Sort rows helper logic
  const sortedTransactions = [...transactions].sort((a, b) => {
    let valA = a[sortField];
    let valB = b[sortField];

    if (typeof valA === "string" && typeof valB === "string") {
      return sortOrder === "asc" ? valA.localeCompare(valB) : valB.localeCompare(valA);
    } else {
      const numA = valA as number;
      const numB = valB as number;
      return sortOrder === "asc" ? numA - numB : numB - numA;
    }
  });

  // Paginated Rows
  const totalPages = Math.max(Math.ceil(sortedTransactions.length / itemsPerPage), 1);
  const paginatedTransactions = sortedTransactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("desc");
    }
    setCurrentPage(1);
  };

  // Submit dynamic individual transaction
  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRow.product.trim() || anyFormError) return;

    const price = parseFloat(String(newRow.price)) || 0;
    const cost = parseFloat(String(newRow.cost)) || 0;
    const quantity = parseInt(String(newRow.quantity), 10) || 1;

    const rev = quantity * price;
    const prof = rev - quantity * cost;

    const invoiceId = `INV-${Math.floor(1000 + Math.random() * 9000)}`;

    const added: Transaction = {
      id: invoiceId,
      date: newRow.date,
      product: newRow.product.trim(),
      category: newRow.category,
      quantity,
      price,
      cost,
      revenue: parseFloat(rev.toFixed(2)),
      profit: parseFloat(prof.toFixed(2)),
      region: newRow.region,
      channel: newRow.channel,
      paymentMethod: newRow.paymentMethod
    };

    onAddTransaction(added);
    // Reset product input
    setNewRow((prev) => ({ ...prev, product: "" }));
    setIsFormOpen(false);
    setCurrentPage(1);
  };

  // CSV Parsing Engine (Handles standard headers or indices intelligently)
  const parseAndAddCSV = (text: string) => {
    try {
      setImporterError("");
      const lines = text.split(/\r?\n/).filter((l) => l.trim() !== "");
      if (lines.length < 2) {
        setImporterError("Insufficient rows. CSV must contain a header row and at least 1 data row.");
        return;
      }

      const headers = lines[0].toLowerCase().split(",").map((h) => h.trim().replace(/['"]/g, ""));
      const parsedRecords: Transaction[] = [];

      for (let i = 1; i < lines.length; i++) {
        // Simple comma split but respecting basic text delimiters
        const row = lines[i].split(",").map((cell) => cell.trim().replace(/['"]/g, ""));
        if (row.length < 6) continue;

        // Try to match headers or fallback to standard indices
        const dateIdx = headers.indexOf("date") !== -1 ? headers.indexOf("date") : 0;
        const productIdx = headers.indexOf("product") !== -1 ? headers.indexOf("product") : 1;
        const categoryIdx = headers.indexOf("category") !== -1 ? headers.indexOf("category") : 2;
        const qtyIdx = headers.indexOf("quantity") !== -1 || headers.indexOf("units") !== -1 
          ? Math.max(headers.indexOf("quantity"), headers.indexOf("units")) 
          : 3;
        const priceIdx = headers.indexOf("price") !== -1 ? headers.indexOf("price") : 4;
        const costIdx = headers.indexOf("cost") !== -1 ? headers.indexOf("cost") : 5;
        
        // Non-essential fallback matching
        const regIdx = headers.indexOf("region") !== -1 ? headers.indexOf("region") : 6;
        const chIdx = headers.indexOf("channel") !== -1 ? headers.indexOf("channel") : 7;
        const pmIdx = headers.indexOf("paymethod") !== -1 || headers.indexOf("payment") !== -1 
          ? Math.max(headers.indexOf("paymethod"), headers.indexOf("payment")) 
          : 8;

        const date = row[dateIdx] || new Date().toISOString().split("T")[0];
        const product = row[productIdx] || "Imported Product";
        const category = row[categoryIdx] || "Electronics";
        const quantity = parseInt(row[qtyIdx], 10) || 1;
        const price = parseFloat(row[priceIdx]) || 100.0;
        const cost = parseFloat(row[costIdx]) || (price * 0.6); // Auto-cost estimation if empty

        const region = row[regIdx] || "North America";
        const channel = row[chIdx] || "Online Store";
        const paymentMethod = row[pmIdx] || "Credit Card";

        const rev = quantity * price;
        const prof = rev - quantity * cost;
        const id = `INV-${Math.floor(10000 + Math.random() * 90000)}`;

        parsedRecords.push({
          id,
          date,
          product,
          category,
          quantity,
          price,
          cost,
          revenue: parseFloat(rev.toFixed(2)),
          profit: parseFloat(prof.toFixed(2)),
          region,
          channel,
          paymentMethod
        });
      }

      if (parsedRecords.length === 0) {
        setImporterError("Could not successfully parse any valid transaction rows. Check headers.");
        return;
      }

      onAddMultipleTransactions(parsedRecords);
      setCsvInput("");
      setIsImporterOpen(false);
      setCurrentPage(1);
    } catch (e: any) {
      setImporterError(`Parsing failure: ${e.message || e}`);
    }
  };

  // Process standard drag-n-drop file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const content = evt.target?.result;
      if (typeof content === "string") {
        parseAndAddCSV(content);
      }
    };
    reader.readAsText(file);
  };

  // Export current list to standard CSV downloads
  const exportToCSV = () => {
    const csvRows = [
      ["InvoiceID", "Date", "Product", "Category", "Quantity", "Price", "Cost", "Revenue", "Profit", "Region", "Channel", "PaymentMethod"]
    ];

    transactions.forEach((t) => {
      csvRows.push([
        t.id,
        t.date,
        `"${t.product}"`,
        `"${t.category}"`,
        String(t.quantity),
        String(t.price),
        String(t.cost),
        String(t.revenue),
        String(t.profit),
        `"${t.region}"`,
        `"${t.channel}"`,
        `"${t.paymentMethod}"`
      ]);
    });

    const csvContent = "data:text/csv;charset=utf-8," + csvRows.map((r) => r.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", encodedUri);
    downloadAnchor.setAttribute("download", `sales_and_revenue_report_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    document.body.removeChild(downloadAnchor);
  };

  return (
    <>
      <div className="bg-[#0c0c0c] border border-[#1a1a1a] rounded-xl overflow-hidden text-[#dcdcdc] print:hidden">
      {/* Table Headers Controls */}
      <div className="p-5 border-b border-[#1a1a1a] flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#050505]">
        <div>
          <h3 className="text-sm font-serif italic text-white flex items-center gap-1">Executive Transaction Ledger</h3>
          <p className="text-xs text-[#555] mt-1">
            Sort, review, record, and integrate sales databases instantly.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          {/* Paste CSV/Excel Drawer Toggle */}
          <button
            onClick={() => setIsImporterOpen(!isImporterOpen)}
            className="text-[10px] uppercase tracking-wider font-mono px-3 py-1.5 rounded bg-[#111] border border-[#222] hover:border-[#c5a05933] text-[#888] hover:text-white flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Upload className="w-3 h-3 text-[#c5a059]" />
            Import CSV / Excel
          </button>

          {/* Export button */}
          <button
            onClick={exportToCSV}
            className="text-[10px] uppercase tracking-wider font-mono px-3 py-1.5 rounded bg-[#111] border border-[#222] text-[#888] hover:text-white hover:border-[#c5a05911] flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Download className="w-3 h-3 text-[#c5a059]" />
            Export CSV
          </button>

          {/* Print Report button */}
          <button
            onClick={() => window.print()}
            className="text-[10px] uppercase tracking-wider font-mono px-3 py-1.5 rounded bg-[#111] border border-[#222] text-[#888] hover:text-white hover:border-[#c5a05911] flex items-center gap-1.5 transition-all cursor-pointer"
            title="Generate Physical Print Sheet"
          >
            <Printer className="w-3.5 h-3.5 text-[#c5a059]" />
            Print Report
          </button>

          {/* Individual manually added form toggle */}
          <button
            onClick={() => setIsFormOpen(!isFormOpen)}
            className="text-[10px] uppercase tracking-wider font-serif italic px-3 py-1.5 rounded bg-[#c5a059] text-black hover:bg-[#d9b56d] flex items-center gap-1.5 transition-all cursor-pointer border-0"
          >
            <Plus className="w-3 h-3 text-black" />
            Add Sale Record
            <kbd className="hidden sm:inline-block ml-1 px-1 py-0.2 rounded bg-black/15 text-black/60 text-[8px] font-sans border border-black/10">Alt+N</kbd>
          </button>
        </div>
      </div>

      {/* CSV / Excel Drag & Paste Importer Section */}
      {isImporterOpen && (
        <div className="bg-[#050505] p-5 border-b border-[#1a1a1a] transition-all">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-[#c5a059]" />
              <h4 className="text-xs font-serif italic text-white">Import Row Matrix</h4>
            </div>
            <button
              onClick={() => {
                setIsImporterOpen(false);
                setImporterError("");
              }}
              className="text-rose-400 hover:text-white uppercase tracking-wider font-mono text-[9px] cursor-pointer"
            >
              Close importer
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-[10px] text-[#555] font-mono leading-relaxed mb-2.5">
                Paste rows from an Excel file or raw CSV. Valid layout columns schema:
                <br />
                <code className="text-[#c5a059] font-mono text-[9px] bg-[#111] border border-[#222] px-1 rounded block mt-1 py-0.5">
                  Date, Product, Category, Quantity, Price, Cost, Region, Channel, PaymentMethod
                </code>
              </p>

              <textarea
                value={csvInput}
                onChange={(e) => setCsvInput(e.target.value)}
                placeholder="2026-06-18,Quantum Alpha Laptop,Electronics,2,1299.99,850.00,North America,Online Store,Credit Card"
                rows={4}
                className="w-full p-2.5 rounded-lg border border-[#222] bg-[#111] focus:border-[#c5a05955] focus:outline-hidden text-xs font-mono text-white placeholder-[#333] transition-all"
              />

              <button
                onClick={() => parseAndAddCSV(csvInput)}
                disabled={!csvInput.trim()}
                className="mt-2 text-[10px] uppercase tracking-wider font-mono px-3 py-1.5 bg-[#c5a059] text-black font-semibold rounded hover:bg-[#d9b56d] disabled:bg-[#111] disabled:text-[#444] disabled:border-[#222] disabled:cursor-not-allowed transition-all cursor-pointer"
              >
                Submit Pasted Rows
              </button>
            </div>

            {/* Drag & Drop File Loader */}
            <div className="flex flex-col items-center justify-center border-2 border-dashed border-[#222] hover:border-[#c5a05933] rounded-lg p-5 text-center bg-[#0c0c0c] hover:bg-[#111] transition-all cursor-pointer"
                 onClick={() => fileInputRef.current?.click()}
            >
              <Upload className="w-6 h-6 text-[#c5a059] mb-2" />
              <span className="text-xs font-medium text-white">Drag and drop spreadsheet file here</span>
              <span className="text-[10px] text-[#555] font-mono mt-1">Supports standard CSV spreadsheets (.csv)</span>
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>
          </div>

          {importerError && (
            <div className="mt-3 text-[10px] bg-[#211111] border border-[#441c1c] text-rose-400 p-2.5 rounded font-mono">
              {importerError}
            </div>
          )}
        </div>
      )}

      {/* Manual Insert Transaction Row Form */}
      {isFormOpen && (
        <form onSubmit={handleAddSubmit} className="bg-[#050505] p-5 border-b border-[#1a1a1a] transition-all grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
          <div className="col-span-2 sm:col-span-3 lg:col-span-5 flex items-center justify-between border-b border-[#1a1a1a] pb-2 mb-1">
            <span className="text-xs font-serif italic text-white">Append Revenue Invoice</span>
            <button
              type="button"
              onClick={() => setIsFormOpen(false)}
              className="text-rose-400 hover:text-white uppercase tracking-wider font-mono text-[9px] cursor-pointer"
            >
              Cancel
            </button>
          </div>

          {/* Product Title */}
          <div className="col-span-2">
            <label className="block text-[10px] font-mono tracking-widest text-[#555] uppercase mb-1">
              Product Description
            </label>
            <input
              ref={productInputRef}
              type="text"
              required
              value={newRow.product}
              onChange={(e) => setNewRow({ ...newRow, product: e.target.value })}
              placeholder="e.g. Laser Printer MX"
              className="w-full px-2.5 py-1.5 rounded-lg border border-[#222] bg-[#111] focus:border-[#c5a05955] text-xs text-white focus:outline-hidden transition-all"
            />
          </div>

          {/* Date Picker */}
          <div>
            <label className="block text-[10px] font-mono tracking-widest text-[#555] uppercase mb-1">
              Sale Date
            </label>
            <input
              type="date"
              required
              value={newRow.date}
              onChange={(e) => setNewRow({ ...newRow, date: e.target.value })}
              className="w-full px-2.5 py-1.5 rounded-lg border border-[#222] bg-[#111] focus:border-[#c5a05955] text-xs text-white focus:outline-hidden transition-all scheme-dark"
            />
          </div>

          {/* Category SELECT */}
          <div>
            <label className="block text-[10px] font-mono tracking-widest text-[#555] uppercase mb-1">
              Category
            </label>
            <select
              value={newRow.category}
              onChange={(e) => setNewRow({ ...newRow, category: e.target.value })}
              className="w-full px-2 py-1.5 rounded-lg border border-[#222] bg-[#111] focus:border-[#c5a05955] text-xs text-white focus:outline-hidden transition-all cursor-pointer"
            >
              {CATEGORIES.filter(c => c !== "All").map((cat) => (
                <option key={cat} value={cat} className="bg-black text-white">
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Region SELECT */}
          <div>
            <label className="block text-[10px] font-mono tracking-widest text-[#555] uppercase mb-1">
              Region
            </label>
            <select
              value={newRow.region}
              onChange={(e) => setNewRow({ ...newRow, region: e.target.value })}
              className="w-full px-2 py-1.5 rounded-lg border border-[#222] bg-[#111] focus:border-[#c5a05955] text-xs text-white focus:outline-hidden transition-all cursor-pointer"
            >
              {REGIONS.filter(r => r !== "All").map((reg) => (
                <option key={reg} value={reg} className="bg-black text-white">
                  {reg}
                </option>
              ))}
            </select>
          </div>

          {/* Quantity */}
          <div>
            <label className="block text-[10px] font-mono tracking-widest text-[#555] uppercase mb-1">
              Units
            </label>
            <input
              type="number"
              min="1"
              required
              value={isNaN(newRow.quantity) ? "" : newRow.quantity}
              onChange={(e) => {
                const val = e.target.value;
                setNewRow({ ...newRow, quantity: val === "" ? "" as any : parseInt(val, 10) });
              }}
              className={`w-full px-2.5 py-1.5 rounded-lg border text-xs text-white focus:outline-hidden transition-all ${
                qtyHasError 
                  ? "border-rose-900 focus:border-rose-500 bg-[#211111]/40" 
                  : "border-[#222] bg-[#111] focus:border-[#c5a05955]"
              }`}
            />
            {qtyHasError && (
              <p className="text-[9px] text-rose-450 font-mono mt-1">⚠️ {qtyError}</p>
            )}
          </div>

          {/* Price */}
          <div>
            <label className="block text-[10px] font-mono tracking-widest text-[#555] uppercase mb-1">
              Price ($)
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              required
              value={isNaN(newRow.price) ? "" : newRow.price}
              onChange={(e) => {
                const val = e.target.value;
                setNewRow({ ...newRow, price: val === "" ? "" as any : parseFloat(val) });
              }}
              className={`w-full px-2.5 py-1.5 rounded-lg border text-xs text-white focus:outline-hidden transition-all ${
                priceHasError 
                  ? "border-rose-900 focus:border-rose-500 bg-[#211111]/40" 
                  : "border-[#222] bg-[#111] focus:border-[#c5a05955]"
              }`}
            />
            {priceHasError && (
              <p className="text-[9px] text-rose-450 font-mono mt-1">⚠️ {priceError}</p>
            )}
          </div>

          {/* Cost */}
          <div>
            <label className="block text-[10px] font-mono tracking-widest text-[#555] uppercase mb-1">
              Cost ($)
            </label>
            <input
              type="number"
              step="0.01"
              min="0"
              required
              value={isNaN(newRow.cost) ? "" : newRow.cost}
              onChange={(e) => {
                const val = e.target.value;
                setNewRow({ ...newRow, cost: val === "" ? "" as any : parseFloat(val) });
              }}
              className={`w-full px-2.5 py-1.5 rounded-lg border text-xs text-white focus:outline-hidden transition-all ${
                costHasError 
                  ? "border-rose-900 focus:border-rose-500 bg-[#211111]/40" 
                  : "border-[#222] bg-[#111] focus:border-[#c5a05955]"
              }`}
            />
            {costHasError && (
              <p className="text-[9px] text-rose-450 font-mono mt-1">⚠️ {costError}</p>
            )}
          </div>

          {/* Sales Channel */}
          <div>
            <label className="block text-[10px] font-mono tracking-widest text-[#555] uppercase mb-1">
              Channel
            </label>
            <select
              value={newRow.channel}
              onChange={(e) => setNewRow({ ...newRow, channel: e.target.value })}
              className="w-full px-2 py-1.5 rounded-lg border border-[#222] bg-[#111] focus:border-[#c5a05955] text-xs text-white focus:outline-hidden transition-all cursor-pointer"
            >
              {CHANNELS.filter(c => c !== "All").map((ch) => (
                <option key={ch} value={ch} className="bg-black text-white">
                  {ch}
                </option>
              ))}
            </select>
          </div>

          {/* Payment Method */}
          <div>
            <label className="block text-[10px] font-mono tracking-widest text-[#555] uppercase mb-1">
              Payment Method
            </label>
            <select
              value={newRow.paymentMethod}
              onChange={(e) => setNewRow({ ...newRow, paymentMethod: e.target.value })}
              className="w-full px-2 py-1.5 rounded-lg border border-[#222] bg-[#111] focus:border-[#c5a05955] text-xs text-white focus:outline-hidden transition-all cursor-pointer"
            >
              {PAYMENT_METHODS.filter(p => p !== "All").map((pm) => (
                <option key={pm} value={pm} className="bg-black text-white">
                  {pm}
                </option>
              ))}
            </select>
          </div>

          {/* Real-time Dynamic Feedback and Calculations Preview Row */}
          <div className="col-span-2 sm:col-span-3 lg:col-span-5 bg-[#080808] border border-[#161616] p-4 rounded-xl mt-1 relative overflow-hidden transition-all">
            <span className="text-[9px] font-mono uppercase tracking-widest text-[#555] block mb-2.5">Real-time Financial Preview</span>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <span className="text-[9px] uppercase tracking-wider text-[#444] font-mono block">Estimated Revenue</span>
                <span className={`text-sm font-mono font-bold ${estimatedRev < 0 ? "text-rose-450" : "text-white"}`}>
                  ${estimatedRev.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
              <div>
                <span className="text-[9px] uppercase tracking-wider text-[#444] font-mono block">Calculated Profit</span>
                <span className={`text-sm font-mono font-bold ${estimatedProfitVal < 0 ? "text-rose-450" : "text-emerald-500"}`}>
                  ${estimatedProfitVal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                {estimatedProfitVal < 0 && !anyFormError && (
                  <span className="text-[8px] text-rose-400 font-mono block mt-0.5">⚠️ Operating at a Loss</span>
                )}
              </div>
              <div>
                <span className="text-[9px] uppercase tracking-wider text-[#444] font-mono block">Projected Margin</span>
                <span className={`text-sm font-mono font-bold ${anyFormError || estimatedMarginVal < 0 ? "text-rose-450" : "text-[#c5a059]"}`}>
                  {anyFormError ? "0.0%" : `${estimatedMarginVal.toFixed(1)}%`}
                </span>
              </div>
              <div>
                <span className="text-[9px] uppercase tracking-wider text-[#444] font-mono block">Validation Standing</span>
                {anyFormError ? (
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse"></span>
                    <span className="text-[9.5px] font-serif italic text-rose-400">Inputs Invalid</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    <span className="text-[9.5px] font-serif italic text-emerald-400">Ready to Commit</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Form Actions submission */}
          <div className="col-span-2 sm:col-span-3 lg:col-span-5 flex justify-end gap-2 mt-2 border-t border-[#1a1a1a] pt-3">
            <button
              type="button"
              onClick={onClearAll}
              className="text-rose-450 hover:bg-[#201010] border border-transparent hover:border-[#381a1a] px-3 py-1.5 rounded text-[10px] uppercase font-mono tracking-wider transition-colors cursor-pointer"
            >
              Clear Entire Ledger
            </button>
            <button
              type="submit"
              disabled={anyFormError}
              className="bg-[#c5a059] hover:bg-[#d9b56d] text-black font-serif italic px-5 py-1.5 rounded text-xs transition-colors cursor-pointer disabled:bg-[#111] disabled:text-[#444] disabled:border-[#1a1a1a] disabled:cursor-not-allowed border border-transparent"
            >
              Append Entry Row
              <kbd className="hidden sm:inline-block ml-1 px-1 py-0.2 rounded bg-black/15 text-black/60 text-[8px] font-sans border border-black/10">Alt+N</kbd>
            </button>
          </div>
        </form>
      )}

      {/* Main Table grid section */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-[#0c0c0c] border-b border-[#1a1a1a] text-[9px] uppercase font-mono tracking-widest text-[#555]">
              <th className="py-3.5 px-5">Invoice ID</th>
              <th className="py-3.5 px-3 cursor-pointer select-none hover:text-white hover:bg-[#111]" onClick={() => toggleSort("date")}>
                <div className="flex items-center gap-1">
                  Date
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th className="py-3.5 px-3">Product Description</th>
              <th className="py-3.5 px-3.5">Category</th>
              <th className="py-3.5 px-3 cursor-pointer select-none hover:text-white hover:bg-[#111]" onClick={() => toggleSort("quantity")}>
                <div className="flex items-center gap-1">
                  Units
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th className="py-3.5 px-3 cursor-pointer select-none hover:text-white hover:bg-[#111]" onClick={() => toggleSort("revenue")}>
                <div className="flex items-center gap-1">
                  Revenue
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th className="py-3.5 px-3 cursor-pointer select-none hover:text-white hover:bg-[#111]" onClick={() => toggleSort("profit")}>
                <div className="flex items-center gap-1">
                  Profit (Margin)
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th className="py-3.5 px-3">Market (Channel)</th>
              <th className="py-3.5 px-4 text-right">Actions</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-[#161616] text-xs text-[#bbb]">
            {paginatedTransactions.length === 0 ? (
              <tr>
                <td colSpan={9} className="py-12 text-center text-[#555]">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <FileSpreadsheet className="w-8 h-8 text-[#222]" />
                    <span className="font-mono text-[10px] uppercase tracking-wider">No transaction instances to display.</span>
                  </div>
                </td>
              </tr>
            ) : (
              paginatedTransactions.map((t) => {
                const margin = t.revenue > 0 ? (t.profit / t.revenue) * 100 : 0;
                return (
                  <tr key={t.id} className="hover:bg-[#111]/30 transition-colors">
                    {/* Invoice Code */}
                    <td className="py-3.5 px-5 font-mono font-semibold text-[#c5a059]">
                      {t.id}
                    </td>

                    {/* Transaction Date */}
                    <td className="py-3.5 px-3 font-mono text-[#555] text-[11px]">
                      {t.date}
                    </td>

                    {/* Product Name */}
                    <td className="py-3.5 px-3 text-[#eee] font-medium truncate max-w-50">
                      {t.product}
                    </td>

                    {/* Category */}
                    <td className="py-3.5 px-3.5">
                      <span className="bg-[#111] border border-[#222] px-2 py-0.5 rounded text-[9px] font-mono uppercase tracking-wider text-[#bbb]">
                        {t.category}
                      </span>
                    </td>

                    {/* Quantity */}
                    <td className="py-3.5 px-3 font-mono text-[#888]">
                      {t.quantity}
                    </td>

                    {/* Total Revenue */}
                    <td className="py-3.5 px-3 font-mono text-white">
                      ${t.revenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>

                    {/* Net Profit & Margin */}
                    <td className="py-3.5 px-3 font-mono">
                      <div className="font-semibold text-[#c5a059]">
                        ${t.profit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </div>
                      <div className="text-[10px] text-[#555]">
                        {margin.toFixed(1)}% margin
                      </div>
                    </td>

                    {/* Region and Channel */}
                    <td className="py-3.5 px-3 text-[#888] font-mono text-[11px]">
                      <div className="text-white font-sans">{t.region}</div>
                      <div className="text-[10px] text-[#555]">{t.channel}</div>
                    </td>

                    {/* Actions and Trashing */}
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => onDeleteTransaction(t.id)}
                        className="p-1 text-[#444] hover:text-rose-450 hover:bg-[#201010] rounded border border-transparent hover:border-[#381a1a] transition-all inline-block cursor-pointer"
                        title="Delete Invoice Row"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Bar widgets */}
      {totalPages > 1 && (
        <div className="p-4 bg-[#050505] border-t border-[#1a1a1a] flex items-center justify-between text-xs text-[#555] font-mono">
          <span>
            PAGE <strong className="text-white">{currentPage}</strong> OF <strong className="text-white">{totalPages}</strong> ({transactions.length} total entries)
          </span>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
              disabled={currentPage === 1}
              className="p-1 rounded bg-[#111] border border-[#222] hover:border-[#c5a05933] hover:text-white text-[#888] disabled:opacity-20 disabled:cursor-not-allowed transition-all cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="p-1 rounded bg-[#111] border border-[#222] hover:border-[#c5a05933] hover:text-white text-[#888] disabled:opacity-20 disabled:cursor-not-allowed transition-all cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>

      {/* 🖨️ Clean, High-Contrast Print-Only Report Ledger (All filtered entries printed inline) */}
      <div className="hidden print:block mt-2 text-black w-full font-sans">
        <div className="border-b-2 border-black pb-3 mb-6">
          <h2 className="text-xl font-serif font-bold tracking-tight text-black">
            EXECUTIVE TRANSACTION LEDGER REPORT
          </h2>
          <div className="flex justify-between items-center text-[10px] font-mono text-stone-600 mt-2">
            <span>PRINT DATE: {new Date().toLocaleDateString(undefined, { dateStyle: 'long' })}</span>
            <span>TOTAL RETRIEVED ENTRIES: {transactions.length} | PHYSICAL AUDIT TRAIL</span>
          </div>
        </div>

        <table className="w-full text-left border-collapse text-[10px]">
          <thead>
            <tr className="border-b-2 border-black text-[9px] uppercase font-mono tracking-wider font-bold bg-neutral-100 text-black">
              <th className="py-2 px-2.5 border border-stone-300 font-bold bg-neutral-100 text-black">Invoice ID</th>
              <th className="py-2 px-2 border border-stone-300 font-bold bg-neutral-100 text-black">Date</th>
              <th className="py-2 px-2.5 border border-stone-300 font-bold bg-neutral-100 text-black">Product Name</th>
              <th className="py-2 px-2 border border-stone-300 font-bold bg-neutral-100 text-black">Category</th>
              <th className="py-2 px-1 border border-stone-300 text-center font-bold bg-neutral-100 text-black">Units</th>
              <th className="py-2 px-2 border border-stone-300 text-right font-bold bg-neutral-100 text-black">Price</th>
              <th className="py-2 px-2 border border-stone-300 text-right font-bold bg-neutral-100 text-black">Cost</th>
              <th className="py-2 px-2 border border-stone-300 text-right font-bold bg-neutral-100 text-black">Revenue</th>
              <th className="py-2 px-2 border border-stone-300 text-right font-bold bg-neutral-100 text-black">Profit</th>
              <th className="py-2 px-2 border border-stone-300 text-right font-bold bg-neutral-100 text-black">Margin</th>
              <th className="py-2 px-2.5 border border-stone-300 font-bold bg-neutral-100 text-black">Region / Channel</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-300">
            {transactions.map((t) => {
              const margin = t.revenue > 0 ? (t.profit / t.revenue) * 100 : 0;
              return (
                <tr key={t.id + "-print"} className="page-break-inside-avoid">
                  <td className="py-1.5 px-2.5 font-mono font-bold text-black border border-stone-300">{t.id}</td>
                  <td className="py-1.5 px-2 font-mono text-stone-700 border border-stone-300">{t.date}</td>
                  <td className="py-1.5 px-2.5 font-medium text-black border border-stone-300 truncate max-w-37.5">{t.product}</td>
                  <td className="py-1.5 px-2 font-sans border border-stone-300">{t.category}</td>
                  <td className="py-1.5 px-1 font-mono text-center border border-stone-300">{t.quantity}</td>
                  <td className="py-1.5 px-2 font-mono text-right border border-stone-300">${t.price.toFixed(2)}</td>
                  <td className="py-1.5 px-2 font-mono text-right border border-stone-300">${t.cost.toFixed(2)}</td>
                  <td className="py-1.5 px-2 font-mono text-right border border-stone-300 font-semibold">${t.revenue.toFixed(2)}</td>
                  <td className="py-1.5 px-2 font-mono text-right border border-stone-300 font-semibold">${t.profit.toFixed(2)}</td>
                  <td className="py-1.5 px-2 font-mono text-right border border-stone-300">{margin.toFixed(1)}%</td>
                  <td className="py-1.5 px-2.5 font-mono text-[9px] border border-stone-300">{t.region} | {t.channel}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}
