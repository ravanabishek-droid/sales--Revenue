/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Transaction } from "./types";

export const DEFAULT_TRANSACTIONS: Transaction[] = [
  {
    id: "INV-1001",
    date: "2026-01-10",
    product: "Quantum Alpha Laptop",
    category: "Electronics",
    quantity: 12,
    price: 1299.99,
    cost: 850.00,
    revenue: 15599.88,
    profit: 5399.88,
    region: "North America",
    channel: "Online Store",
    paymentMethod: "Credit Card"
  },
  {
    id: "INV-1002",
    date: "2026-01-15",
    product: "Meridian Ergonomic Chair",
    category: "Office Supplies",
    quantity: 25,
    price: 349.99,
    cost: 180.00,
    revenue: 8749.75,
    profit: 4249.75,
    region: "Europe",
    channel: "Online Store",
    paymentMethod: "PayPal"
  },
  {
    id: "INV-1003",
    date: "2026-02-04",
    product: "AeroPulse Running Shoes",
    category: "Fitness & Sport",
    quantity: 45,
    price: 120.00,
    cost: 45.00,
    revenue: 5400.00,
    profit: 3375.00,
    region: "Asia-Pacific",
    channel: "Mobile App",
    paymentMethod: "Credit Card"
  },
  {
    id: "INV-1004",
    date: "2026-02-18",
    product: "Titanium Cookware Set",
    category: "Home & Kitchen",
    quantity: 8,
    price: 499.00,
    cost: 250.00,
    revenue: 3992.00,
    profit: 1992.00,
    region: "Latin America",
    channel: "Retail Outlet",
    paymentMethod: "Bank Transfer"
  },
  {
    id: "INV-1005",
    date: "2026-02-22",
    product: "Vortex ANC Headphones",
    category: "Electronics",
    quantity: 30,
    price: 199.99,
    cost: 95.00,
    revenue: 5999.70,
    profit: 3149.70,
    region: "North America",
    channel: "Online Store",
    paymentMethod: "Crypto"
  },
  {
    id: "INV-1006",
    date: "2026-03-02",
    product: "Solar Charging Backpack",
    category: "Apparel",
    quantity: 50,
    price: 89.99,
    cost: 35.00,
    revenue: 4499.50,
    profit: 2749.50,
    region: "Europe",
    channel: "Online Store",
    paymentMethod: "PayPal"
  },
  {
    id: "INV-1007",
    date: "2026-03-12",
    product: "Apex Mechanical Keyboard",
    category: "Electronics",
    quantity: 18,
    price: 149.50,
    cost: 70.00,
    revenue: 2691.00,
    profit: 1431.00,
    region: "Asia-Pacific",
    channel: "Mobile App",
    paymentMethod: "Credit Card"
  },
  {
    id: "INV-1008",
    date: "2026-03-24",
    product: "Bamboo Standing Desk",
    category: "Office Supplies",
    quantity: 10,
    price: 649.00,
    cost: 320.00,
    revenue: 6490.00,
    profit: 3290.00,
    region: "North America",
    channel: "Retail Outlet",
    paymentMethod: "Bank Transfer"
  },
  {
    id: "INV-1009",
    date: "2026-04-05",
    product: "Breeze Air Purifier",
    category: "Home & Kitchen",
    quantity: 20,
    price: 249.99,
    cost: 110.00,
    revenue: 4999.80,
    profit: 2799.80,
    region: "Europe",
    channel: "Online Store",
    paymentMethod: "Credit Card"
  },
  {
    id: "INV-1010",
    date: "2026-04-14",
    product: "Summit Hiking Jacket",
    category: "Apparel",
    quantity: 40,
    price: 179.99,
    cost: 80.00,
    revenue: 7199.60,
    profit: 3999.60,
    region: "Latin America",
    channel: "Retail Outlet",
    paymentMethod: "Credit Card"
  },
  {
    id: "INV-1011",
    date: "2026-04-22",
    product: "Krypton Curved Monitor",
    category: "Electronics",
    quantity: 15,
    price: 449.99,
    cost: 260.00,
    revenue: 6749.85,
    profit: 2849.85,
    region: "Asia-Pacific",
    channel: "Online Store",
    paymentMethod: "Bank Transfer"
  },
  {
    id: "INV-1012",
    date: "2026-05-03",
    product: "Zen Bamboo Bedding Set",
    category: "Home & Kitchen",
    quantity: 35,
    price: 119.99,
    cost: 50.00,
    revenue: 4199.65,
    profit: 2449.65,
    region: "North America",
    channel: "Mobile App",
    paymentMethod: "PayPal"
  },
  {
    id: "INV-1013",
    date: "2026-05-15",
    product: "ThermaFit Hydration Vest",
    category: "Fitness & Sport",
    quantity: 55,
    price: 79.99,
    cost: 30.00,
    revenue: 4399.45,
    profit: 2749.45,
    region: "Europe",
    channel: "Online Store",
    paymentMethod: "Credit Card"
  },
  {
    id: "INV-1014",
    date: "2026-05-28",
    product: "OmniSmart Security Camera",
    category: "Electronics",
    quantity: 28,
    price: 159.99,
    cost: 80.00,
    revenue: 4479.72,
    profit: 2239.72,
    region: "Latin America",
    channel: "Mobile App",
    paymentMethod: "Crypto"
  },
  {
    id: "INV-1015",
    date: "2026-06-02",
    product: "DuoMat Cork Yoga Mat",
    category: "Fitness & Sport",
    quantity: 80,
    price: 49.99,
    cost: 18.00,
    revenue: 3999.20,
    profit: 2559.20,
    region: "North America",
    channel: "Online Store",
    paymentMethod: "PayPal"
  },
  {
    id: "INV-1016",
    date: "2026-06-10",
    product: "AeroPulse Running Shoes",
    category: "Fitness & Sport",
    quantity: 32,
    price: 120.00,
    cost: 45.00,
    revenue: 3840.00,
    profit: 2400.00,
    region: "Europe",
    channel: "Retail Outlet",
    paymentMethod: "Credit Card"
  },
  {
    id: "INV-1017",
    date: "2026-06-15",
    product: "Quantum Alpha Laptop",
    category: "Electronics",
    quantity: 5,
    price: 1299.99,
    cost: 850.00,
    revenue: 6499.95,
    profit: 2249.95,
    region: "Asia-Pacific",
    channel: "Online Store",
    paymentMethod: "Credit Card"
  },
  {
    id: "INV-1018",
    date: "2026-06-18",
    product: "Minimalist Leather Cardholder",
    category: "Apparel",
    quantity: 110,
    price: 35.00,
    cost: 12.00,
    revenue: 3850.00,
    profit: 2530.00,
    region: "North America",
    channel: "Online Store",
    paymentMethod: "Credit Card"
  }
];

export const CATEGORIES = [
  "All",
  "Electronics",
  "Office Supplies",
  "Fitness & Sport",
  "Home & Kitchen",
  "Apparel"
];

export const REGIONS = [
  "All",
  "North America",
  "Europe",
  "Asia-Pacific",
  "Latin America"
];

export const CHANNELS = [
  "All",
  "Online Store",
  "Mobile App",
  "Retail Outlet"
];

export const PAYMENT_METHODS = [
  "All",
  "Credit Card",
  "PayPal",
  "Bank Transfer",
  "Crypto"
];
