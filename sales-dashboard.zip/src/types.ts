/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Transaction {
  id: string;
  date: string; // YYYY-MM-DD
  product: string;
  category: string;
  quantity: number;
  price: number;
  cost: number;
  revenue: number;
  profit: number;
  region: string;
  channel: string;
  paymentMethod: string;
}

export interface DashboardFilters {
  startDate: string;
  endDate: string;
  category: string;
  region: string;
  channel: string;
  paymentMethod: string;
  searchQuery: string;
}

export interface KpiSummary {
  totalRevenue: number;
  totalProfit: number;
  avgMargin: number;
  totalOrders: number;
  avgOrderValue: number;
  totalQuantity: number;
}

export interface CategoryBreakdown {
  category: string;
  revenue: number;
  profit: number;
  units: number;
}

export interface RegionalBreakdown {
  region: string;
  revenue: number;
  units: number;
  profit: number;
}

export interface ProductLeaderboard {
  product: string;
  category: string;
  revenue: number;
  units: number;
  profit: number;
  margin: number;
}

export interface MonthlyTrend {
  month: string; // YYYY-MM
  revenue: number;
  profit: number;
  units: number;
}
